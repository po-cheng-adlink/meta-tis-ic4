
#include "Allocator.h"
#include "BufferPool.h"
#include "DeviceEnum.h"
#include "Display.h"
#include "Error.h"
#include "ImageBuffer.h"
#include "ImageType.h"
#include "Grabber.h"
#include "HandleRef.h"
#include "InitLibrary.h"
#include "Properties.h"
#include "PropertyConstants.h"
#include "PropId.h"
#include "QueueSink.h"
#include "SaveImages.h"
#include "Sink.h"
#include "SnapSink.h"
#include "StringUtil.h"
#include "VideoWriter.h"
#include "Version.h"

#ifdef _MSC_VER
#pragma comment(lib, "ic4core")
#endif
