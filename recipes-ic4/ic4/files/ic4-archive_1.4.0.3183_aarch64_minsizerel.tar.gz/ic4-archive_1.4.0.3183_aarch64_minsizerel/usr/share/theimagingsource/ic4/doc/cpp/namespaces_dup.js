var namespaces_dup =
[
    [ "ic4", "namespaceic4.html", "namespaceic4" ],
    [ "ic4gui", "namespaceic4gui.html", "namespaceic4gui" ],
    [ "ic4interop", "namespaceic4interop.html", "namespaceic4interop" ]
];