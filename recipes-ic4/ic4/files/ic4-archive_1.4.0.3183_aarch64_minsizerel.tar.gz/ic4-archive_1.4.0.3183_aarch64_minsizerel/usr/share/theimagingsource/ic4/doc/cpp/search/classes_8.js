var searchData=
[
  ['metadata_0',['MetaData',['../structic4_1_1_image_buffer_1_1_meta_data.html',1,'ic4::ImageBuffer']]]
];
