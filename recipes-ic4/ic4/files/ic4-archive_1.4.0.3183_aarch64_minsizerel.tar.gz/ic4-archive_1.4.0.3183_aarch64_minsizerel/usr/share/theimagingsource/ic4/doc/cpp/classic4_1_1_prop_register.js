var classic4_1_1_prop_register =
[
    [ "getValue", "classic4_1_1_prop_register.html#a9d8f81e6b7fac40e42618c7c4ace4502", null ],
    [ "setValue", "classic4_1_1_prop_register.html#a8be1f92e6fffd7e1a468037963cf4178", null ],
    [ "size", "classic4_1_1_prop_register.html#a715498b2499ad5ad25652893ccaa5d15", null ]
];