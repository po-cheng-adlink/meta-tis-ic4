var searchData=
[
  ['0_0',['IC Imaging Control 4 Version 1.0',['../whatsnew.html#changes_1_0',1,'']]]
];
