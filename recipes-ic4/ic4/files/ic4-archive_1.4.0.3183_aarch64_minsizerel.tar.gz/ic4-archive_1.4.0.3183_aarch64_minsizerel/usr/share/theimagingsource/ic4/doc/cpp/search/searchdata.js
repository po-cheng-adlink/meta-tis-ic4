var indexSectionsWithContent =
{
  0: "01234abcdefghilmnopqrstuvwxyz",
  1: "abcdeghimopqsv",
  2: "i",
  3: "abcdefghimnopqrstuvw",
  4: "abcdefghilmnopqrstuwz",
  5: "dnrw",
  6: "acdelpstv",
  7: "abcdefghilmnopqrstuvwy",
  8: "01234abcdefghilmnopqrstuvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

