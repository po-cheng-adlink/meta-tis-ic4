var searchData=
[
  ['what_20s_20new_0',['What s New',['../whatsnew.html',1,'What&apos;s New'],['../index.html#main_whatsnew',1,'What's New']]],
  ['width_1',['width',['../struct_i_c4___i_m_a_g_e___t_y_p_e.html#a325272ddd9a962f05deb905101d25cbd',1,'IC4_IMAGE_TYPE']]],
  ['windows_2',['Windows',['../minimal_requirements.html#windows_requiremets',1,'Windows'],['../technical_article_distributing_your_applications.html#distribution_windows',1,'Windows']]],
  ['writer_3',['Video Writer',['../group__videowriter.html',1,'']]]
];
