var searchData=
[
  ['packages_0',['Packages',['../technical_article_distributing_your_applications.html#distributing_linux_package_content',1,'']]],
  ['pitch_1',['pitch',['../struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a8b9619114eefd65cd8c9804ad6154215',1,'IC4_BUFFERPOOL_ALLOCATION_OPTIONS']]],
  ['pixel_5fformat_2',['pixel_format',['../struct_i_c4___i_m_a_g_e___t_y_p_e.html#a96abb64301e2663893851df3d166d50d',1,'IC4_IMAGE_TYPE']]],
  ['pixel_5fformats_3',['pixel_formats',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284',1,'IC4_QUEUESINK_CONFIG::pixel_formats'],['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284',1,'IC4_SNAPSINK_CONFIG::pixel_formats']]],
  ['plugin_20display_20deb_4',['plugin display deb',['../guide_getting_started.html#gettingstarted_linux_package_content_display',1,'ic4-plugin-display.deb'],['../technical_article_distributing_your_applications.html#distributing_linux_package_content_display',1,'ic4-plugin-display.deb']]],
  ['plugin_20encoder_20deb_5',['plugin encoder deb',['../guide_getting_started.html#gettingstarted_linux_package_content_encoder',1,'ic4-plugin-encoder.deb'],['../technical_article_distributing_your_applications.html#distributing_linux_package_content_encoder',1,'ic4-plugin-encoder.deb']]],
  ['programmer_20s_20guide_6',['Programmer s Guide',['../programmers_guide.html',1,'Programmer&apos;s Guide'],['../index.html#main_programmers_guide',1,'Programmer's Guide']]],
  ['programs_7',['Programs',['../example_programs.html',1,'Example Programs'],['../index.html#mainpage_example_programs',1,'Example Programs']]],
  ['project_8',['Setting Up the Project',['../guide_getting_started.html#gs_setup',1,'']]],
  ['properties_9',['Properties',['../technical_article_properties.html',1,'Accessing Device Properties'],['../group__boolprop.html',1,'Boolean Properties'],['../group__catprop.html',1,'Category Properties'],['../group__cmdprop.html',1,'Command Properties'],['../whatsnew_from35.html#changedconcepts35properties',1,'Device Properties'],['../group__enumprop.html',1,'Enumeration Properties'],['../group__floatprop.html',1,'Float Properties'],['../group__intprop.html',1,'Integer Properties'],['../group__properties.html',1,'Properties'],['../group__regprop.html',1,'Register Properties'],['../group__stringprop.html',1,'String Properties']]],
  ['property_20identifiers_10',['Property Identifiers',['../group__propid.html',1,'Property Identifiers'],['../technical_article_properties.html#article_properties_propertyids',1,'Property Identifiers']]],
  ['property_20lists_11',['Property Lists',['../group__proplist.html',1,'']]],
  ['property_20map_12',['Property Map',['../group__propmap.html',1,'Property Map'],['../technical_article_properties.html#article_properties_propertymap',1,'Property Map']]],
  ['property_20objects_13',['Property Objects',['../group__propobj.html',1,'Property Objects'],['../technical_article_properties.html#article_properties_propertyobjects',1,'Property Objects']]],
  ['property_20types_14',['Specialized Property Types',['../technical_article_properties.html#article_properties_propertytypes',1,'']]]
];
