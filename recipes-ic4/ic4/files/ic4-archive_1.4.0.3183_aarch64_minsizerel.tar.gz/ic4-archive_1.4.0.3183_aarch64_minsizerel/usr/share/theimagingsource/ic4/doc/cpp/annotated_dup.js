var annotated_dup =
[
    [ "ic4", "namespaceic4.html", [
      [ "PropId", "namespaceic4_1_1_prop_id.html", [
        [ "PropIdBoolean", "structic4_1_1_prop_id_1_1_prop_id_boolean.html", null ],
        [ "PropIdCommand", "structic4_1_1_prop_id_1_1_prop_id_command.html", null ],
        [ "PropIdEnumeration", "structic4_1_1_prop_id_1_1_prop_id_enumeration.html", null ],
        [ "PropIdFloat", "structic4_1_1_prop_id_1_1_prop_id_float.html", null ],
        [ "PropIdInteger", "structic4_1_1_prop_id_1_1_prop_id_integer.html", null ],
        [ "PropIdRegister", "structic4_1_1_prop_id_1_1_prop_id_register.html", null ],
        [ "PropIdString", "structic4_1_1_prop_id_1_1_prop_id_string.html", null ]
      ] ],
      [ "BufferAllocator", "structic4_1_1_buffer_allocator.html", "structic4_1_1_buffer_allocator" ],
      [ "BufferPool", "classic4_1_1_buffer_pool.html", "classic4_1_1_buffer_pool" ],
      [ "DeviceEnum", "classic4_1_1_device_enum.html", "classic4_1_1_device_enum" ],
      [ "DeviceInfo", "classic4_1_1_device_info.html", "classic4_1_1_device_info" ],
      [ "Display", "classic4_1_1_display.html", "classic4_1_1_display" ],
      [ "DisplayStatistics", "structic4_1_1_display_statistics.html", "structic4_1_1_display_statistics" ],
      [ "Error", "classic4_1_1_error.html", "classic4_1_1_error" ],
      [ "ExternalOpenGLDisplay", "classic4_1_1_external_open_g_l_display.html", "classic4_1_1_external_open_g_l_display" ],
      [ "Grabber", "classic4_1_1_grabber.html", "classic4_1_1_grabber" ],
      [ "IC4Exception", "classic4_1_1_i_c4_exception.html", "classic4_1_1_i_c4_exception" ],
      [ "ImageBuffer", "classic4_1_1_image_buffer.html", "classic4_1_1_image_buffer" ],
      [ "ImageType", "structic4_1_1_image_type.html", "structic4_1_1_image_type" ],
      [ "InitLibraryConfig", "structic4_1_1_init_library_config.html", "structic4_1_1_init_library_config" ],
      [ "Interface", "classic4_1_1_interface.html", "classic4_1_1_interface" ],
      [ "PropBoolean", "classic4_1_1_prop_boolean.html", "classic4_1_1_prop_boolean" ],
      [ "PropCategory", "classic4_1_1_prop_category.html", "classic4_1_1_prop_category" ],
      [ "PropCommand", "classic4_1_1_prop_command.html", "classic4_1_1_prop_command" ],
      [ "PropEnumEntry", "classic4_1_1_prop_enum_entry.html", "classic4_1_1_prop_enum_entry" ],
      [ "PropEnumeration", "classic4_1_1_prop_enumeration.html", "classic4_1_1_prop_enumeration" ],
      [ "Property", "classic4_1_1_property.html", "classic4_1_1_property" ],
      [ "PropertyMap", "classic4_1_1_property_map.html", "classic4_1_1_property_map" ],
      [ "PropFloat", "classic4_1_1_prop_float.html", "classic4_1_1_prop_float" ],
      [ "PropInteger", "classic4_1_1_prop_integer.html", "classic4_1_1_prop_integer" ],
      [ "PropRegister", "classic4_1_1_prop_register.html", "classic4_1_1_prop_register" ],
      [ "PropString", "classic4_1_1_prop_string.html", "classic4_1_1_prop_string" ],
      [ "QueueSink", "classic4_1_1_queue_sink.html", "classic4_1_1_queue_sink" ],
      [ "QueueSinkListener", "classic4_1_1_queue_sink_listener.html", "classic4_1_1_queue_sink_listener" ],
      [ "SaveBitmapOptions", "structic4_1_1_save_bitmap_options.html", "structic4_1_1_save_bitmap_options" ],
      [ "SaveJpegOptions", "structic4_1_1_save_jpeg_options.html", "structic4_1_1_save_jpeg_options" ],
      [ "SavePngOptions", "structic4_1_1_save_png_options.html", "structic4_1_1_save_png_options" ],
      [ "SaveTiffOptions", "structic4_1_1_save_tiff_options.html", "structic4_1_1_save_tiff_options" ],
      [ "Sink", "classic4_1_1_sink.html", "classic4_1_1_sink" ],
      [ "SnapSink", "classic4_1_1_snap_sink.html", "classic4_1_1_snap_sink" ],
      [ "VideoWriter", "classic4_1_1_video_writer.html", "classic4_1_1_video_writer" ]
    ] ],
    [ "ic4gui", "namespaceic4gui.html", [
      [ "PropertyDialogOptions", "structic4gui_1_1_property_dialog_options.html", "structic4gui_1_1_property_dialog_options" ]
    ] ],
    [ "ic4interop", "namespaceic4interop.html", [
      [ "Qt", "namespaceic4interop_1_1_qt.html", [
        [ "DisplayWidget", "classic4interop_1_1_qt_1_1_display_widget.html", "classic4interop_1_1_qt_1_1_display_widget" ],
        [ "DisplayWindow", "classic4interop_1_1_qt_1_1_display_window.html", "classic4interop_1_1_qt_1_1_display_window" ]
      ] ],
      [ "HALCON", "classic4interop_1_1_h_a_l_c_o_n.html", null ],
      [ "OpenCV", "classic4interop_1_1_open_c_v.html", null ]
    ] ]
];