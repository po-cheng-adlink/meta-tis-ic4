var classic4interop_1_1_qt_1_1_display_window =
[
    [ "DisplayWindow", "classic4interop_1_1_qt_1_1_display_window.html#a6c7b62a65bfb1061d933d339a2d2afb7", null ],
    [ "asDisplay", "classic4interop_1_1_qt_1_1_display_window.html#a60509402fd70c4a68225810e0d96a915", null ]
];