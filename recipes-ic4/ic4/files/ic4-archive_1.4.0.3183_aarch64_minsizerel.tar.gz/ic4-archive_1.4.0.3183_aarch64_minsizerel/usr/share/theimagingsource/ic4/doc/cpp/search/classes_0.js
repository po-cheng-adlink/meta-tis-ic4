var searchData=
[
  ['allocationoptions_0',['AllocationOptions',['../structic4_1_1_buffer_pool_1_1_allocation_options.html',1,'ic4::BufferPool']]]
];
