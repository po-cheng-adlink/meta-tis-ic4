var classic4_1_1_prop_string =
[
    [ "getValue", "classic4_1_1_prop_string.html#a17eaf25bcfd56f9088b2bc57241c25c7", null ],
    [ "maxLength", "classic4_1_1_prop_string.html#a82664f8e57398c0bb05b1795315b394f", null ],
    [ "setValue", "classic4_1_1_prop_string.html#afc41620823bca63deac01653928545d0", null ]
];