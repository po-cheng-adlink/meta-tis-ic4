var classic4interop_1_1_qt_1_1_display_widget =
[
    [ "DisplayWidget", "classic4interop_1_1_qt_1_1_display_widget.html#a04f3a614fc85beca53a972fb4e11252a", null ],
    [ "asDisplay", "classic4interop_1_1_qt_1_1_display_widget.html#a60509402fd70c4a68225810e0d96a915", null ]
];