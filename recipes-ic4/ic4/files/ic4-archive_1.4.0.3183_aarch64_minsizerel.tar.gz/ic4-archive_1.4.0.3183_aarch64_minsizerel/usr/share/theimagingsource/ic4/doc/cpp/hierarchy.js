var hierarchy =
[
    [ "BufferPool::AllocationOptions", "structic4_1_1_buffer_pool_1_1_allocation_options.html", null ],
    [ "BufferAllocator", "structic4_1_1_buffer_allocator.html", null ],
    [ "BufferPool", "classic4_1_1_buffer_pool.html", null ],
    [ "BufferPool::CacheConfig", "structic4_1_1_buffer_pool_1_1_cache_config.html", null ],
    [ "QueueSink::Config", "structic4_1_1_queue_sink_1_1_config.html", null ],
    [ "SnapSink::Config", "structic4_1_1_snap_sink_1_1_config.html", null ],
    [ "SnapSink::CustomAllocationStrategy", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html", null ],
    [ "DeviceEnum", "classic4_1_1_device_enum.html", null ],
    [ "DeviceInfo", "classic4_1_1_device_info.html", null ],
    [ "Display", "classic4_1_1_display.html", [
      [ "ExternalOpenGLDisplay", "classic4_1_1_external_open_g_l_display.html", null ]
    ] ],
    [ "DisplayStatistics", "structic4_1_1_display_statistics.html", null ],
    [ "Error", "classic4_1_1_error.html", null ],
    [ "exception", null, [
      [ "IC4Exception", "classic4_1_1_i_c4_exception.html", null ]
    ] ],
    [ "Grabber", "classic4_1_1_grabber.html", null ],
    [ "HALCON", "classic4interop_1_1_h_a_l_c_o_n.html", null ],
    [ "ImageBuffer", "classic4_1_1_image_buffer.html", null ],
    [ "ImageType", "structic4_1_1_image_type.html", null ],
    [ "InitLibraryConfig", "structic4_1_1_init_library_config.html", null ],
    [ "Interface", "classic4_1_1_interface.html", null ],
    [ "ImageBuffer::MetaData", "structic4_1_1_image_buffer_1_1_meta_data.html", null ],
    [ "OpenCV", "classic4interop_1_1_open_c_v.html", null ],
    [ "Property", "classic4_1_1_property.html", [
      [ "PropBoolean", "classic4_1_1_prop_boolean.html", null ],
      [ "PropCategory", "classic4_1_1_prop_category.html", null ],
      [ "PropCommand", "classic4_1_1_prop_command.html", null ],
      [ "PropEnumEntry", "classic4_1_1_prop_enum_entry.html", null ],
      [ "PropEnumeration", "classic4_1_1_prop_enumeration.html", null ],
      [ "PropFloat", "classic4_1_1_prop_float.html", null ],
      [ "PropInteger", "classic4_1_1_prop_integer.html", null ],
      [ "PropRegister", "classic4_1_1_prop_register.html", null ],
      [ "PropString", "classic4_1_1_prop_string.html", null ]
    ] ],
    [ "PropertyDialogOptions", "structic4gui_1_1_property_dialog_options.html", null ],
    [ "PropertyMap", "classic4_1_1_property_map.html", null ],
    [ "PropIdBoolean", "structic4_1_1_prop_id_1_1_prop_id_boolean.html", null ],
    [ "PropIdCommand", "structic4_1_1_prop_id_1_1_prop_id_command.html", null ],
    [ "PropIdEnumeration", "structic4_1_1_prop_id_1_1_prop_id_enumeration.html", null ],
    [ "PropIdFloat", "structic4_1_1_prop_id_1_1_prop_id_float.html", null ],
    [ "PropIdInteger", "structic4_1_1_prop_id_1_1_prop_id_integer.html", null ],
    [ "PropIdRegister", "structic4_1_1_prop_id_1_1_prop_id_register.html", null ],
    [ "PropIdString", "structic4_1_1_prop_id_1_1_prop_id_string.html", null ],
    [ "QMainWindow", null, [
      [ "DisplayWindow", "classic4interop_1_1_qt_1_1_display_window.html", null ]
    ] ],
    [ "QueueSinkListener", "classic4_1_1_queue_sink_listener.html", null ],
    [ "QueueSink::QueueSizes", "structic4_1_1_queue_sink_1_1_queue_sizes.html", null ],
    [ "QWidget", null, [
      [ "DisplayWidget", "classic4interop_1_1_qt_1_1_display_widget.html", null ]
    ] ],
    [ "SaveBitmapOptions", "structic4_1_1_save_bitmap_options.html", null ],
    [ "SaveJpegOptions", "structic4_1_1_save_jpeg_options.html", null ],
    [ "SavePngOptions", "structic4_1_1_save_png_options.html", null ],
    [ "SaveTiffOptions", "structic4_1_1_save_tiff_options.html", null ],
    [ "Sink", "classic4_1_1_sink.html", [
      [ "QueueSink", "classic4_1_1_queue_sink.html", null ],
      [ "SnapSink", "classic4_1_1_snap_sink.html", null ]
    ] ],
    [ "Grabber::StreamStatistics", "structic4_1_1_grabber_1_1_stream_statistics.html", null ],
    [ "VideoWriter", "classic4_1_1_video_writer.html", null ]
];