var classic4_1_1_i_c4_exception =
[
    [ "code", "classic4_1_1_i_c4_exception.html#a80fd7b61ea5ca48eb58d6157f146fbca", null ],
    [ "what", "classic4_1_1_i_c4_exception.html#a13eaa5d9d991702b03b0ac5228d46cbd", null ]
];