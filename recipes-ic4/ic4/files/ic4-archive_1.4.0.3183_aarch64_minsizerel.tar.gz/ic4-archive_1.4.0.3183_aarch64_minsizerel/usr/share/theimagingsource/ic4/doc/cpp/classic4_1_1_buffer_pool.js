var classic4_1_1_buffer_pool =
[
    [ "AllocationOptions", "structic4_1_1_buffer_pool_1_1_allocation_options.html", "structic4_1_1_buffer_pool_1_1_allocation_options" ],
    [ "CacheConfig", "structic4_1_1_buffer_pool_1_1_cache_config.html", "structic4_1_1_buffer_pool_1_1_cache_config" ],
    [ "getBuffer", "classic4_1_1_buffer_pool.html#af4196c74e30db7676d82fa96fadd9740", null ],
    [ "getBuffer", "classic4_1_1_buffer_pool.html#af90c6d145c821fa2c9a9e752a00fd4da", null ]
];