var searchData=
[
  ['releasememoryhandler_0',['ReleaseMemoryHandler',['../classic4_1_1_image_buffer.html#ac5ce8ac105f748145c05a5b2358605cb',1,'ic4::ImageBuffer']]]
];
