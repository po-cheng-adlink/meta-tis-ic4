var searchData=
[
  ['cacheconfig_0',['CacheConfig',['../structic4_1_1_buffer_pool_1_1_cache_config.html',1,'ic4::BufferPool']]],
  ['config_1',['Config',['../structic4_1_1_queue_sink_1_1_config.html',1,'QueueSink::Config'],['../structic4_1_1_snap_sink_1_1_config.html',1,'SnapSink::Config']]],
  ['customallocationstrategy_2',['CustomAllocationStrategy',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html',1,'ic4::SnapSink']]]
];
