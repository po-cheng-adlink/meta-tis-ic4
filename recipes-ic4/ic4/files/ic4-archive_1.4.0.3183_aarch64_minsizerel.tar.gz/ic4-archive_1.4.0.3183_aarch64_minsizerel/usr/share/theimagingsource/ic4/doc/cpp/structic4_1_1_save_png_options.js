var structic4_1_1_save_png_options =
[
    [ "compression_level", "structic4_1_1_save_png_options.html#a921dfb4896d031670e614035039c65f0", null ],
    [ "store_raw_bayer_data_as_monochrome", "structic4_1_1_save_png_options.html#a746996e64254362c0eafb77085bb23eb", null ]
];