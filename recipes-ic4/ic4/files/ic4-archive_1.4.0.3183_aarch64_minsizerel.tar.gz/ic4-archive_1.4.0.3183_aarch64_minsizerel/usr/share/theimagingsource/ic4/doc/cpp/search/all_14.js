var searchData=
[
  ['rates_0',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['receiving_20device_20arrival_20and_20removal_20notifications_1',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['reference_2',['API Reference',['../index.html#mainpage_api_reference',1,'']]],
  ['register_3',['Register',['../namespaceic4.html#ac6a79184a0a7c1d2e3ea745512aa2d0ca0ba7583639a274c434bbe6ef797115a4',1,'ic4']]],
  ['releasememoryhandler_4',['ReleaseMemoryHandler',['../classic4_1_1_image_buffer.html#ac5ce8ac105f748145c05a5b2358605cb',1,'ic4::ImageBuffer']]],
  ['removal_20notifications_5',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['renamed_20concepts_6',['Renamed Concepts',['../whatsnew_from35.html#rewording35',1,'']]],
  ['render_7',['render',['../classic4_1_1_external_open_g_l_display.html#aa1ecf63edd9a2363fee061acb0b5a639',1,'ic4::ExternalOpenGLDisplay']]],
  ['representation_8',['representation',['../classic4_1_1_prop_integer.html#a9076e853ceeee2ee86ddf7eaae5affe6',1,'ic4::PropInteger::representation()'],['../classic4_1_1_prop_float.html#a0c202ea37a6b165e7ffafc45be5a5690',1,'ic4::PropFloat::representation()']]],
  ['requirements_9',['Minimal Requirements',['../minimal_requirements.html',1,'programmers_guide']]],
  ['reserved0_10',['reserved0',['../structic4_1_1_init_library_config.html#af739c5839fbc080ce2b6f70f24961d4b',1,'ic4::InitLibraryConfig']]],
  ['resolution_11',['Configure the Resolution',['../guide_configuring_device.html#gcd_configure_resolution',1,'']]],
  ['restorestateoncancel_12',['RestoreStateOnCancel',['../namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aa6c611790d0e632356d57241feaad2289',1,'ic4gui']]],
  ['reversex_13',['ReverseX',['../namespaceic4_1_1_prop_id.html#a8265106fc94bd2f71f6e539cd523f9dd',1,'ic4::PropId']]],
  ['reversey_14',['ReverseY',['../namespaceic4_1_1_prop_id.html#ac03579c39dc685a4f49bc0027f57619b',1,'ic4::PropId']]],
  ['roi_20origin_15',['Define ROI Origin',['../guide_configuring_device.html#gcd_roi_origin',1,'']]],
  ['run_16',['Run',['../classic4_1_1_sink.html#ada1f25ce8b6a2e35ca2a001e25ec01e9ac5301693c4e792bcd5a479ef38fb8f8d',1,'ic4::Sink']]]
];
