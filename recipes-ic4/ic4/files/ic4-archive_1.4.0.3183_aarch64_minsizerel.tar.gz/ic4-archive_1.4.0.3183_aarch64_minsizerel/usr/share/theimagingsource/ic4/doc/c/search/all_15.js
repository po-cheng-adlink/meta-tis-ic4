var searchData=
[
  ['rates_0',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['receiving_20device_20arrival_20and_20removal_20notifications_1',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['reference_2',['API Reference',['../index.html#mainpage_api_reference',1,'']]],
  ['register_20properties_3',['Register Properties',['../group__regprop.html',1,'']]],
  ['release_4',['release',['../struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a309bd385472fe5a580067cc27a9cc19a',1,'IC4_ALLOCATOR_CALLBACKS::release'],['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a309bd385472fe5a580067cc27a9cc19a',1,'IC4_QUEUESINK_CALLBACKS::release']]],
  ['removal_20notifications_5',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['renamed_20concepts_6',['Renamed Concepts',['../whatsnew_from35.html#rewording35',1,'']]],
  ['requirements_7',['Minimal Requirements',['../minimal_requirements.html',1,'programmers_guide']]],
  ['reserved0_8',['reserved0',['../struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#af739c5839fbc080ce2b6f70f24961d4b',1,'IC4_INIT_CONFIG']]],
  ['resolution_9',['Configure the Resolution',['../guide_configuring_device.html#gcd_configure_resolution',1,'']]],
  ['roi_20origin_10',['Define ROI Origin',['../guide_configuring_device.html#gcd_roi_origin',1,'']]]
];
