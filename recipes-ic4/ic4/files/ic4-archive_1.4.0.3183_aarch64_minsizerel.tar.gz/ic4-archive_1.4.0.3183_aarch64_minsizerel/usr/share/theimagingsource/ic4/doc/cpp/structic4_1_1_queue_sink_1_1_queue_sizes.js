var structic4_1_1_queue_sink_1_1_queue_sizes =
[
    [ "free_queue_length", "structic4_1_1_queue_sink_1_1_queue_sizes.html#ac86292452a5be9525a58b73a40354abf", null ],
    [ "output_queue_length", "structic4_1_1_queue_sink_1_1_queue_sizes.html#abeddbceb1598ad07d061a33d1e00927d", null ]
];