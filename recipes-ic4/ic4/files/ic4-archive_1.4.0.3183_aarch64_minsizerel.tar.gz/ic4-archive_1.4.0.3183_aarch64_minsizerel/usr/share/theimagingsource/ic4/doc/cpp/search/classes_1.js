var searchData=
[
  ['bufferallocator_0',['BufferAllocator',['../structic4_1_1_buffer_allocator.html',1,'ic4']]],
  ['bufferpool_1',['BufferPool',['../classic4_1_1_buffer_pool.html',1,'ic4']]]
];
