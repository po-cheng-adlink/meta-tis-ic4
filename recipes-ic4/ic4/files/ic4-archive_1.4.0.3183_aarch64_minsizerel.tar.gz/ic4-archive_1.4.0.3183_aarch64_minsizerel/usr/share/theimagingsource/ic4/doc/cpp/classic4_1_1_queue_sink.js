var classic4_1_1_queue_sink =
[
    [ "Config", "structic4_1_1_queue_sink_1_1_config.html", "structic4_1_1_queue_sink_1_1_config" ],
    [ "QueueSizes", "structic4_1_1_queue_sink_1_1_queue_sizes.html", "structic4_1_1_queue_sink_1_1_queue_sizes" ],
    [ "allocAndQueueBuffers", "classic4_1_1_queue_sink.html#a94da664935be7380587cadb33736e9be", null ],
    [ "isCancelRequested", "classic4_1_1_queue_sink.html#a5856ce35197d74dfc5f996a3136d8a44", null ],
    [ "outputImageType", "classic4_1_1_queue_sink.html#a6e27acb23a70ed2c03b6bc3d6ad056cd", null ],
    [ "popOutputBuffer", "classic4_1_1_queue_sink.html#a065e815d8268d12b9387bc6f4a8f5798", null ],
    [ "queueSizes", "classic4_1_1_queue_sink.html#a9cf8dc3e4c56fed08bfec08b1bfccd32", null ],
    [ "sinkType", "classic4_1_1_queue_sink.html#a97dac7bcfe21d2073c88b7432424bff1", null ]
];