var searchData=
[
  ['4_0',['Differences between IC Imaging Control 3.x tisgrabber and IC Imaging Control 4',['../whatsnew_from35.html#diff35',1,'']]],
  ['4_20version_201_200_1',['IC Imaging Control 4 Version 1.0',['../whatsnew.html#changes_1_0',1,'']]],
  ['4_20version_201_201_2',['IC Imaging Control 4 Version 1.1',['../whatsnew.html#changes_1_1',1,'']]]
];
