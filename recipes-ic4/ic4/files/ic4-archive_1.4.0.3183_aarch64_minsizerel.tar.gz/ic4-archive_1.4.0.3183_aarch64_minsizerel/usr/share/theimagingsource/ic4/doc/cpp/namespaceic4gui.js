var namespaceic4gui =
[
    [ "PropertyDialogOptions", "structic4gui_1_1_property_dialog_options.html", "structic4gui_1_1_property_dialog_options" ],
    [ "PropertyDialogFlags", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504a", [
      [ "Default", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aa7a1920d61156abc05a60135aefe8bc67", null ],
      [ "AllowStreamRestart", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aa6f303a470bcb3fc5c0db3f378123170b", null ],
      [ "RestoreStateOnCancel", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aa6c611790d0e632356d57241feaad2289", null ],
      [ "ShowTopCategory", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aadada16f08f5cca2327d1b747000ba740", null ],
      [ "HideFilter", "namespaceic4gui.html#ac3bc382edf9335e5f00fd4f4e67b504aa70da5bf2bd831ba9b796e5f854c6a142", null ]
    ] ],
    [ "showDeviceDialog", "namespaceic4gui.html#a816743a90cbd3dd89cb2ed5a035987d3", null ],
    [ "showDevicePropertyDialog", "namespaceic4gui.html#a515d9458112ca43cbdf3e2559327dc6f", null ],
    [ "showPropertyDialog", "namespaceic4gui.html#a7261ca937d9205a7af9706db1d98b56f", null ],
    [ "showSelectDeviceDialog", "namespaceic4gui.html#a9f4f5b2946f41231fe67b819cda765fd", null ]
];