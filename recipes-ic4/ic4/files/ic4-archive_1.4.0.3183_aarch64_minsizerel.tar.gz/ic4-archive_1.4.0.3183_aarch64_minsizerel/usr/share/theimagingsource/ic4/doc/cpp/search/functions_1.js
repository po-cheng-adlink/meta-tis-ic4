var searchData=
[
  ['beginfile_0',['beginFile',['../classic4_1_1_video_writer.html#a6aac276e4138ebd599416f017d852142',1,'ic4::VideoWriter::beginFile(const char *file_name, const ImageType &amp;image_type, double frame_rate, Error &amp;err=Error::Default())'],['../classic4_1_1_video_writer.html#a125ebf3a9afd0265273244de00a6d320',1,'ic4::VideoWriter::beginFile(const std::string &amp;file_name, const ImageType &amp;image_type, double frame_rate, Error &amp;err=Error::Default())']]],
  ['buffersize_1',['bufferSize',['../classic4_1_1_image_buffer.html#a4c3e37542426405f81219481c3471ab4',1,'ic4::ImageBuffer']]]
];
