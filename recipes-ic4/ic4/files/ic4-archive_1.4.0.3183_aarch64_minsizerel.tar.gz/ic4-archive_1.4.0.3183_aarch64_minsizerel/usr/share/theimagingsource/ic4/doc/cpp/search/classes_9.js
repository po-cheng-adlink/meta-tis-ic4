var searchData=
[
  ['opencv_0',['OpenCV',['../classic4interop_1_1_open_c_v.html',1,'ic4interop']]]
];
