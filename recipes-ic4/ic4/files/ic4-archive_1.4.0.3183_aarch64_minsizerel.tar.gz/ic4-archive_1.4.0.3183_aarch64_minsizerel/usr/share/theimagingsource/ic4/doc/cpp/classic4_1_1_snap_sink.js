var classic4_1_1_snap_sink =
[
    [ "Config", "structic4_1_1_snap_sink_1_1_config.html", "structic4_1_1_snap_sink_1_1_config" ],
    [ "CustomAllocationStrategy", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy" ],
    [ "AllocationStrategy", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5f", [
      [ "Default", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5fa7a1920d61156abc05a60135aefe8bc67", null ],
      [ "Custom", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5fa90589c47f06eb971d548591f23c285af", null ]
    ] ],
    [ "outputImageType", "classic4_1_1_snap_sink.html#a6e27acb23a70ed2c03b6bc3d6ad056cd", null ],
    [ "sinkType", "classic4_1_1_snap_sink.html#a97dac7bcfe21d2073c88b7432424bff1", null ],
    [ "snapSequence", "classic4_1_1_snap_sink.html#aad37f747b554b7b40eeab07cf7f00f49", null ],
    [ "snapSequence", "classic4_1_1_snap_sink.html#af83cafc8272a99947e5ea7aaf1c81ecf", null ],
    [ "snapSingle", "classic4_1_1_snap_sink.html#a012324cfd002aa7b5c05ebc0c6340a3e", null ],
    [ "snapSingle", "classic4_1_1_snap_sink.html#a37f550e3865f69423e2e4df29a226d6d", null ]
];