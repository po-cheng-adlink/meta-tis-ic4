var searchData=
[
  ['notificationhandler_0',['NotificationHandler',['../classic4_1_1_property.html#a114ca0dcb49e6d523b5b1925726334c7',1,'ic4::Property']]],
  ['notificationtoken_1',['NotificationToken',['../classic4_1_1_device_enum.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::DeviceEnum::NotificationToken'],['../classic4_1_1_display.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Display::NotificationToken'],['../classic4_1_1_grabber.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Grabber::NotificationToken'],['../classic4_1_1_property.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Property::NotificationToken']]]
];
