var structic4_1_1_buffer_pool_1_1_allocation_options =
[
    [ "alignment", "structic4_1_1_buffer_pool_1_1_allocation_options.html#a3afda29223eeda35afd21a6c5e121ba2", null ],
    [ "buffer_size", "structic4_1_1_buffer_pool_1_1_allocation_options.html#a799a743b3abd553a37fc01ad3097df08", null ],
    [ "pitch", "structic4_1_1_buffer_pool_1_1_allocation_options.html#a8b9619114eefd65cd8c9804ad6154215", null ]
];