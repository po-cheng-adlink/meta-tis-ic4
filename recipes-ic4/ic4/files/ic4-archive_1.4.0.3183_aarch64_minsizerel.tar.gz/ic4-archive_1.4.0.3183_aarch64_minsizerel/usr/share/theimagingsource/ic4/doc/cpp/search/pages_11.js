var searchData=
[
  ['objects_0',['Property Objects',['../technical_article_properties.html#article_properties_propertyobjects',1,'']]],
  ['open_20a_20device_1',['Open a Device',['../guide_configuring_device.html#gcd_open_device',1,'']]],
  ['opened_2',['Device Opened',['../technical_article_grabber_states.html#state_device_opened',1,'']]],
  ['opening_20and_20configuring_20the_20video_20capture_20device_3',['Opening and Configuring the Video Capture Device',['../guide_grabbing_an_image.html#gi_open',1,'']]],
  ['origin_4',['Define ROI Origin',['../guide_configuring_device.html#gcd_roi_origin',1,'']]]
];
