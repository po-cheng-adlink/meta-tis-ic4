var structic4gui_1_1_property_dialog_options =
[
    [ "category", "structic4gui_1_1_property_dialog_options.html#ad153dc5a1af8457498a6cecf0dba0b62", null ],
    [ "flags", "structic4gui_1_1_property_dialog_options.html#a3ad0cf6d3862981d9c692637266604ef", null ],
    [ "initial_filter", "structic4gui_1_1_property_dialog_options.html#a458b7e2d08a469b3060cf0dd920f2c12", null ],
    [ "initial_visibility", "structic4gui_1_1_property_dialog_options.html#a3af2ceb9b92f3aa3c330d3d6d9eb6d59", null ],
    [ "title", "structic4gui_1_1_property_dialog_options.html#ac30fed21fe991cc8475ce543929f8b72", null ]
];