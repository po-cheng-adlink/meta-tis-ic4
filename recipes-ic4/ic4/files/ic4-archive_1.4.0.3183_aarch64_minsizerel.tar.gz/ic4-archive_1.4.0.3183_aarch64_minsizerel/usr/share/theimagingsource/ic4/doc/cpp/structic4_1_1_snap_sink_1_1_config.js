var structic4_1_1_snap_sink_1_1_config =
[
    [ "acceptedPixelFormats", "structic4_1_1_snap_sink_1_1_config.html#a513c067e9556ce31592b9c4fa128d47e", null ],
    [ "allocationStrategy", "structic4_1_1_snap_sink_1_1_config.html#a02b1eb24523550f84c9e9b146547fbba", null ],
    [ "bufferAllocator", "structic4_1_1_snap_sink_1_1_config.html#a8e9dc0d2af5f5e06ddf331840edad505", null ],
    [ "customAllocationStrategy", "structic4_1_1_snap_sink_1_1_config.html#a8b2c66363a01cd406cf1d0b89e47bb8b", null ]
];