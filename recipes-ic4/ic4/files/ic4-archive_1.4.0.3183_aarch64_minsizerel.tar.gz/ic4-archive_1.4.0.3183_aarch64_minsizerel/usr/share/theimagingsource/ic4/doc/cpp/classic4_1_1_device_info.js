var classic4_1_1_device_info =
[
    [ "DeviceInfo", "classic4_1_1_device_info.html#a127d6382e1a3d627020745d50a6b9587", null ],
    [ "getInterface", "classic4_1_1_device_info.html#aa577376d96ab3b09e0999d43b2e538c3", null ],
    [ "is_valid", "classic4_1_1_device_info.html#a8f3163cdc2ec7303fd4be1854f4f931e", null ],
    [ "modelName", "classic4_1_1_device_info.html#af533a6c0d94d2f7670fbc690aa16d82a", null ],
    [ "operator!=", "classic4_1_1_device_info.html#af0f0b82c917ca94b62371ace7e8556d5", null ],
    [ "operator==", "classic4_1_1_device_info.html#a5a8e429a3386c574fdf5c525bdc59500", null ],
    [ "serial", "classic4_1_1_device_info.html#ad323facbef9317be4d9ca78af2af8c69", null ],
    [ "uniqueName", "classic4_1_1_device_info.html#ad02f96b22dddd225f04deec896b9dfbe", null ],
    [ "userID", "classic4_1_1_device_info.html#af42fc112c2094b747cd743ee555db20d", null ],
    [ "version", "classic4_1_1_device_info.html#a8172b75d997629756cc96a718b63a3fd", null ]
];