var searchData=
[
  ['uniquename_0',['uniqueName',['../classic4_1_1_device_info.html#ad02f96b22dddd225f04deec896b9dfbe',1,'ic4::DeviceInfo']]],
  ['unit_1',['unit',['../classic4_1_1_prop_integer.html#ab613d0e1d59c51b332a38c073672f076',1,'ic4::PropInteger::unit()'],['../classic4_1_1_prop_float.html#ab613d0e1d59c51b332a38c073672f076',1,'ic4::PropFloat::unit()']]],
  ['userid_2',['userID',['../classic4_1_1_device_info.html#af42fc112c2094b747cd743ee555db20d',1,'ic4::DeviceInfo']]]
];
