var classic4_1_1_device_enum =
[
    [ "DeviceListChangedHandler", "classic4_1_1_device_enum.html#ae02e99b6c07756d5915131f3948de02d", null ],
    [ "NotificationToken", "classic4_1_1_device_enum.html#a8924aa88eef5b96530c0d6e352aa530e", null ],
    [ "DeviceEnum", "classic4_1_1_device_enum.html#ad33c4005d8df4b639eb6a8ce06fc40c7", null ],
    [ "eventAddDeviceListChanged", "classic4_1_1_device_enum.html#ab8dcec35489468f8c470c9643ad84454", null ],
    [ "eventRemoveDeviceListChanged", "classic4_1_1_device_enum.html#a3748fe382359e0041b2f406cafea9f25", null ],
    [ "is_valid", "classic4_1_1_device_enum.html#a8f3163cdc2ec7303fd4be1854f4f931e", null ]
];