var searchData=
[
  ['allocationstrategy_0',['AllocationStrategy',['../classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5f',1,'ic4::SnapSink']]]
];
