var searchData=
[
  ['devicelistchangedhandler_0',['DeviceListChangedHandler',['../classic4_1_1_device_enum.html#ae02e99b6c07756d5915131f3948de02d',1,'ic4::DeviceEnum']]],
  ['devicelosthandler_1',['DeviceLostHandler',['../classic4_1_1_grabber.html#a81841e2c5034253b616ca430401883d3',1,'ic4::Grabber']]]
];
