var structic4_1_1_queue_sink_1_1_config =
[
    [ "acceptedPixelFormats", "structic4_1_1_queue_sink_1_1_config.html#a513c067e9556ce31592b9c4fa128d47e", null ],
    [ "bufferAllocator", "structic4_1_1_queue_sink_1_1_config.html#a8e9dc0d2af5f5e06ddf331840edad505", null ],
    [ "maxOutputBuffers", "structic4_1_1_queue_sink_1_1_config.html#ad3b66651c1c9a357e1c2f2963c797247", null ]
];