var searchData=
[
  ['cache_5fbytes_5fmax_0',['cache_bytes_max',['../struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#ae938b780ec8f759168ee82247b22870d',1,'IC4_BUFFER_POOL_CONFIG']]],
  ['cache_5fframes_5fmax_1',['cache_frames_max',['../struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a639c541ea330c5a9681a629bca06b1a5',1,'IC4_BUFFER_POOL_CONFIG']]],
  ['callback_5fcontext_2',['callback_context',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a67b5953b36108e04f24abe803bc1fe44',1,'IC4_QUEUESINK_CONFIG']]],
  ['callbacks_3',['callbacks',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a10d41ab705ab975fa6266a447881b614',1,'IC4_QUEUESINK_CONFIG']]],
  ['category_4',['category',['../struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#a125628117df0d6a7dd6caa43f2afa61c',1,'IC4_PROPERTY_DIALOG_OPTIONS']]],
  ['compression_5flevel_5',['compression_level',['../struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___p_n_g.html#ae1b570b709d899314a89e12d1dca5ae2',1,'IC4_IMAGEBUFFER_SAVE_OPTIONS_PNG']]]
];
