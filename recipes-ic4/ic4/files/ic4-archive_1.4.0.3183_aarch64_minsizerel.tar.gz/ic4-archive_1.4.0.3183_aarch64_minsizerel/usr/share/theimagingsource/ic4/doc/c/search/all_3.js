var searchData=
[
  ['3_0',['IC Imaging Control4 Version 1.3',['../whatsnew.html#changes_1_3',1,'']]],
  ['3_205_20tisgrabber_1',['Transitioning from IC Imaging Control 3.5 tisgrabber',['../whatsnew_from35.html',1,'whatsnew']]],
  ['3_20x_20tisgrabber_20and_20ic_20imaging_20control_204_2',['Differences between IC Imaging Control 3.x tisgrabber and IC Imaging Control 4',['../whatsnew_from35.html#diff35',1,'']]]
];
