var classic4_1_1_prop_command =
[
    [ "execute", "classic4_1_1_prop_command.html#a11ed8acebc3bcb36dc49f979b15b5682", null ],
    [ "isDone", "classic4_1_1_prop_command.html#aa5b7708dc0de7a4062e5f3564a558564", null ]
];