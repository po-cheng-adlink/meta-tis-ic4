var classic4_1_1_prop_float =
[
    [ "displayNotation", "classic4_1_1_prop_float.html#a178b6aa20f807e6b989c006eb50e7eea", null ],
    [ "displayPrecision", "classic4_1_1_prop_float.html#a8ad7cc5460fea6b0ce16251cac9e139d", null ],
    [ "getValue", "classic4_1_1_prop_float.html#a7aa134499323c2809f0c19ae58ff3bc3", null ],
    [ "increment", "classic4_1_1_prop_float.html#a69a85f7fed98488a1424d4b9d7268953", null ],
    [ "incrementMode", "classic4_1_1_prop_float.html#ad85be8790116e279da1cbf72e99b73fa", null ],
    [ "maximum", "classic4_1_1_prop_float.html#ae83c8d8ce41c4cf7d59e2a688d3f1cf4", null ],
    [ "minimum", "classic4_1_1_prop_float.html#aa2985e527a35b5373087704bd734806c", null ],
    [ "representation", "classic4_1_1_prop_float.html#a0c202ea37a6b165e7ffafc45be5a5690", null ],
    [ "setValue", "classic4_1_1_prop_float.html#a23f78bcdd0ba442f6942b3646848b253", null ],
    [ "unit", "classic4_1_1_prop_float.html#ab613d0e1d59c51b332a38c073672f076", null ],
    [ "validValueSet", "classic4_1_1_prop_float.html#ab3fe5c0eebdedc881d01eedaeda7f6fa", null ]
];