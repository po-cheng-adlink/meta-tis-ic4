var searchData=
[
  ['name_0',['name',['../classic4_1_1_property.html#a93649c939bf1abead63f512f725cd71e',1,'ic4::Property']]],
  ['new_1',['New',['../whatsnew.html',1,'What&apos;s New'],['../index.html#main_whatsnew',1,'What's New']]],
  ['nodata_2',['NoData',['../namespaceic4.html#a59e56af19e754a6aa26a612ebf91d05facbf169aecd4365561eb6b245659f55d8',1,'ic4']]],
  ['noerror_3',['NoError',['../namespaceic4.html#a59e56af19e754a6aa26a612ebf91d05fa70a47cae4eb221930f2663fd244369ea',1,'ic4']]],
  ['none_4',['None',['../namespaceic4.html#a9c86a4eb28445564f5896c02f362d3c9a6adf97f83acf6453d4a6a4b1070f3754',1,'ic4']]],
  ['norms_20frame_20rates_5',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['notificationhandler_6',['NotificationHandler',['../classic4_1_1_property.html#a114ca0dcb49e6d523b5b1925726334c7',1,'ic4::Property']]],
  ['notifications_7',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['notificationtoken_8',['NotificationToken',['../classic4_1_1_device_enum.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::DeviceEnum::NotificationToken'],['../classic4_1_1_display.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Display::NotificationToken'],['../classic4_1_1_grabber.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Grabber::NotificationToken'],['../classic4_1_1_property.html#a8924aa88eef5b96530c0d6e352aa530e',1,'ic4::Property::NotificationToken']]],
  ['notifywindowclosed_9',['notifyWindowClosed',['../classic4_1_1_external_open_g_l_display.html#a8f9ce07dc7db4d0d32caa5ef6f63bc14',1,'ic4::ExternalOpenGLDisplay']]],
  ['num_5fbuffers_5fallocate_5fon_5fconnect_10',['num_buffers_allocate_on_connect',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a710f9bc03d8f28a29ab699afe31b63e0',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5fallocation_5fthreshold_11',['num_buffers_allocation_threshold',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#ab2ffd6fd78a9f7f66614ff6dfa4bb962',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5ffree_5fthreshold_12',['num_buffers_free_threshold',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a61db113746532d34085b650bda9cf2c7',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5fmax_13',['num_buffers_max',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a12fbf2c094cff7313d39854d8da7ed75',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fframes_5fdisplayed_14',['num_frames_displayed',['../structic4_1_1_display_statistics.html#ac9cd5dd300c6438c82021c0e2dc90be5',1,'ic4::DisplayStatistics']]],
  ['num_5fframes_5fdropped_15',['num_frames_dropped',['../structic4_1_1_display_statistics.html#afcea9bf1389f82988d205a8d2d5f68a4',1,'ic4::DisplayStatistics']]]
];
