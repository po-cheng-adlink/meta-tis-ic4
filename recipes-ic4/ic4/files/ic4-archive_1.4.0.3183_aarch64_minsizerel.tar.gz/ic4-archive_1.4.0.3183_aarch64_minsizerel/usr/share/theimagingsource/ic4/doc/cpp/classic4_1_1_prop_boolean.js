var classic4_1_1_prop_boolean =
[
    [ "getValue", "classic4_1_1_prop_boolean.html#a9556aa0c6bd09151bd7eaf85adf4ab5f", null ],
    [ "setValue", "classic4_1_1_prop_boolean.html#ab54a0c4ec515aaf305eea4876b500be3", null ]
];