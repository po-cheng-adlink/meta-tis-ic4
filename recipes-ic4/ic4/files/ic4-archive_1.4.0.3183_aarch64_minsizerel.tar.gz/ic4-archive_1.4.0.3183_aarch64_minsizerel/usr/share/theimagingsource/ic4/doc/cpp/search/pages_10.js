var searchData=
[
  ['new_0',['New',['../whatsnew.html',1,'What&apos;s New'],['../index.html#main_whatsnew',1,'What's New']]],
  ['norms_20frame_20rates_1',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['notifications_2',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]]
];
