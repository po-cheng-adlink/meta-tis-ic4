var structic4_1_1_snap_sink_1_1_custom_allocation_strategy =
[
    [ "num_buffers_allocate_on_connect", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a710f9bc03d8f28a29ab699afe31b63e0", null ],
    [ "num_buffers_allocation_threshold", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#ab2ffd6fd78a9f7f66614ff6dfa4bb962", null ],
    [ "num_buffers_free_threshold", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a61db113746532d34085b650bda9cf2c7", null ],
    [ "num_buffers_max", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a12fbf2c094cff7313d39854d8da7ed75", null ]
];