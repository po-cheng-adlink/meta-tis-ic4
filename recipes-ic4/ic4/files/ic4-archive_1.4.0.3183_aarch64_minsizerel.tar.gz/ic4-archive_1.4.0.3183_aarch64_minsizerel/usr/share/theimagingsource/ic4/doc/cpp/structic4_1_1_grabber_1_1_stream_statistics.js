var structic4_1_1_grabber_1_1_stream_statistics =
[
    [ "device_delivered", "structic4_1_1_grabber_1_1_stream_statistics.html#ab62d16cc71398e9362feb3320b4705cb", null ],
    [ "device_transform_underrun", "structic4_1_1_grabber_1_1_stream_statistics.html#a5074cff63bae255d547fba0277698eaf", null ],
    [ "device_transmission_error", "structic4_1_1_grabber_1_1_stream_statistics.html#ad6c254ea67852baa501a3758861aa871", null ],
    [ "device_underrun", "structic4_1_1_grabber_1_1_stream_statistics.html#ae8447e6f4ed71ef03da194f914b48190", null ],
    [ "sink_delivered", "structic4_1_1_grabber_1_1_stream_statistics.html#a673e9a1d04f627c29566c03786acdb32", null ],
    [ "sink_ignored", "structic4_1_1_grabber_1_1_stream_statistics.html#af3bb58455258708a592040f6de679ef9", null ],
    [ "sink_underrun", "structic4_1_1_grabber_1_1_stream_statistics.html#ac57952db1e7a91bebd90906cc686d87d", null ],
    [ "transform_delivered", "structic4_1_1_grabber_1_1_stream_statistics.html#a24a49808b1a533ddc8c81ef9d8af49d1", null ],
    [ "transform_underrun", "structic4_1_1_grabber_1_1_stream_statistics.html#ad47903278206a6937c8b9d4bde7613a4", null ]
];