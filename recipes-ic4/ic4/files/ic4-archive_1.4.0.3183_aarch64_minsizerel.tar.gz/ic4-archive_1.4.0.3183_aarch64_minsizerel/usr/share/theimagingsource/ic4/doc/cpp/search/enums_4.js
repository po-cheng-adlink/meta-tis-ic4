var searchData=
[
  ['loglevel_0',['LogLevel',['../namespaceic4.html#aca1fd1d8935433e6ba2e3918214e07f9',1,'ic4']]],
  ['logtarget_1',['LogTarget',['../namespaceic4.html#a9a6763291bee1a106f9a817c72692e97',1,'ic4']]]
];
