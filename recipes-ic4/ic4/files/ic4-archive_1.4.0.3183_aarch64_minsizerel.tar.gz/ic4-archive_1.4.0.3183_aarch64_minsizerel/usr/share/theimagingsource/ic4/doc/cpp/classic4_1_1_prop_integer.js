var classic4_1_1_prop_integer =
[
    [ "getValue", "classic4_1_1_prop_integer.html#ad8c68329710bb14ed27a3453c75f7be3", null ],
    [ "increment", "classic4_1_1_prop_integer.html#a9afb2b2ee84669a0748cf6d20fa94b7a", null ],
    [ "incrementMode", "classic4_1_1_prop_integer.html#ad85be8790116e279da1cbf72e99b73fa", null ],
    [ "maximum", "classic4_1_1_prop_integer.html#ac875cd5d3d51e3cb1c5071e5c13110d9", null ],
    [ "minimum", "classic4_1_1_prop_integer.html#aaf05b0e0f678eee82df74a402f0d22f9", null ],
    [ "representation", "classic4_1_1_prop_integer.html#a9076e853ceeee2ee86ddf7eaae5affe6", null ],
    [ "setValue", "classic4_1_1_prop_integer.html#a7a7113f8c42f3c66e514e926e3b6a38d", null ],
    [ "unit", "classic4_1_1_prop_integer.html#ab613d0e1d59c51b332a38c073672f076", null ],
    [ "validValueSet", "classic4_1_1_prop_integer.html#a4fb5638eefff8284eed57dd9cad46793", null ]
];