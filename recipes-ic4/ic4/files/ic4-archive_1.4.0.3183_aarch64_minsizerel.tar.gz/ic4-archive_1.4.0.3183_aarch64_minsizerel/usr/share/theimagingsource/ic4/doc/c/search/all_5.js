var searchData=
[
  ['5_20tisgrabber_0',['Transitioning from IC Imaging Control 3.5 tisgrabber',['../whatsnew_from35.html',1,'whatsnew']]]
];
