var searchData=
[
  ['4_20c_20class_20library_0',['Differences between IC Imaging Control 3.x Class Library and IC Imaging Control 4 C++ Class Library',['../whatsnew_from35.html#diff35',1,'']]],
  ['4_20version_201_200_1',['IC Imaging Control 4 Version 1.0',['../whatsnew.html#changes_1_0',1,'']]],
  ['4_20version_201_201_2',['IC Imaging Control 4 Version 1.1',['../whatsnew.html#changes_1_1',1,'']]],
  ['4_20version_201_202_3',['IC Imaging Control 4 Version 1.2',['../whatsnew.html#changes_1_2',1,'']]],
  ['4_20version_201_203_4',['IC Imaging Control 4 Version 1.3',['../whatsnew.html#changes_1_3',1,'']]]
];
