var searchData=
[
  ['x_20c_20class_20library_0',['Transitioning from IC Imaging Control 3.x C++ Class Library',['../whatsnew_from35.html',1,'whatsnew']]],
  ['x_20class_20library_20and_20ic_20imaging_20control_204_20c_20class_20library_1',['Differences between IC Imaging Control 3.x Class Library and IC Imaging Control 4 C++ Class Library',['../whatsnew_from35.html#diff35',1,'']]]
];
