var classic4_1_1_queue_sink_listener =
[
    [ "framesQueued", "classic4_1_1_queue_sink_listener.html#a45af3716c88acd61154f09f78fc9d91d", null ],
    [ "sinkConnected", "classic4_1_1_queue_sink_listener.html#a6b6e879ec8c8ac5a263a38e56372084a", null ],
    [ "sinkDisconnected", "classic4_1_1_queue_sink_listener.html#ac4edab3f232736d850793c2a4637dd51", null ]
];