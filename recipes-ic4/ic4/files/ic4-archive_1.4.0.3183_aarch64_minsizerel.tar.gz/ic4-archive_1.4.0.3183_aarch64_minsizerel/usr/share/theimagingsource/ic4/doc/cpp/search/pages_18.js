var searchData=
[
  ['version_201_200_0',['IC Imaging Control 4 Version 1.0',['../whatsnew.html#changes_1_0',1,'']]],
  ['version_201_201_1',['IC Imaging Control 4 Version 1.1',['../whatsnew.html#changes_1_1',1,'']]],
  ['version_201_202_2',['IC Imaging Control 4 Version 1.2',['../whatsnew.html#changes_1_2',1,'']]],
  ['version_201_203_3',['IC Imaging Control 4 Version 1.3',['../whatsnew.html#changes_1_3',1,'']]],
  ['version_20history_4',['Version History',['../whatsnew.html#whatsnew_history',1,'']]],
  ['video_20capture_20device_5',['Video Capture Device',['../guide_configuring_device.html',1,'Configuring a Video Capture Device'],['../guide_grabbing_an_image.html#gi_open',1,'Opening and Configuring the Video Capture Device']]],
  ['video_20files_6',['Video Files',['../whatsnew_from35.html#changedconcepts35video',1,'']]],
  ['video_20formats_20video_20norms_20frame_20rates_7',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['video_20norms_20frame_20rates_8',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['visual_20studio_9',['Using Microsoft Visual Studio',['../guide_getting_started.html#gs_vs',1,'']]]
];
