var searchData=
[
  ['num_5fbuffers_5fallocate_5fon_5fconnect_0',['num_buffers_allocate_on_connect',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a710f9bc03d8f28a29ab699afe31b63e0',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5fallocation_5fthreshold_1',['num_buffers_allocation_threshold',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#ab2ffd6fd78a9f7f66614ff6dfa4bb962',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5ffree_5fthreshold_2',['num_buffers_free_threshold',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a61db113746532d34085b650bda9cf2c7',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fbuffers_5fmax_3',['num_buffers_max',['../structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html#a12fbf2c094cff7313d39854d8da7ed75',1,'ic4::SnapSink::CustomAllocationStrategy']]],
  ['num_5fframes_5fdisplayed_4',['num_frames_displayed',['../structic4_1_1_display_statistics.html#ac9cd5dd300c6438c82021c0e2dc90be5',1,'ic4::DisplayStatistics']]],
  ['num_5fframes_5fdropped_5',['num_frames_dropped',['../structic4_1_1_display_statistics.html#afcea9bf1389f82988d205a8d2d5f68a4',1,'ic4::DisplayStatistics']]]
];
