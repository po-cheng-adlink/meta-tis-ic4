var searchData=
[
  ['windowclosedhandler_0',['WindowClosedHandler',['../classic4_1_1_display.html#aa940a055cf4364e9893995c5c6affedc',1,'ic4::Display']]],
  ['windowhandle_1',['WindowHandle',['../namespaceic4.html#a3ede60bad0519f8a1335a3c791f5f7e6',1,'ic4']]]
];
