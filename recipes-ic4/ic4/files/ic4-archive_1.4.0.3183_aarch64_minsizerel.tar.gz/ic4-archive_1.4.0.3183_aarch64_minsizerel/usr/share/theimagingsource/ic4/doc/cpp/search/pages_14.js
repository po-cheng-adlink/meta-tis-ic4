var searchData=
[
  ['rates_0',['Video Formats, Video Norms, Frame Rates',['../whatsnew_from35.html#changedconcepts35formats',1,'']]],
  ['receiving_20device_20arrival_20and_20removal_20notifications_1',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['reference_2',['API Reference',['../index.html#mainpage_api_reference',1,'']]],
  ['removal_20notifications_3',['Receiving Device Arrival and Removal Notifications',['../guide_device_enumeration.html#article_device_enumeration_notifications',1,'']]],
  ['renamed_20concepts_4',['Renamed Concepts',['../whatsnew_from35.html#rewording35',1,'']]],
  ['requirements_5',['Minimal Requirements',['../minimal_requirements.html',1,'programmers_guide']]],
  ['resolution_6',['Configure the Resolution',['../guide_configuring_device.html#gcd_configure_resolution',1,'']]],
  ['roi_20origin_7',['Define ROI Origin',['../guide_configuring_device.html#gcd_roi_origin',1,'']]]
];
