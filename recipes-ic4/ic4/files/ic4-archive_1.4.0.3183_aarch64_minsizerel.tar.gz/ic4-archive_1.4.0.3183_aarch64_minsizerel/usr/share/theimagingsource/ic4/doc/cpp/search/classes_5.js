var searchData=
[
  ['grabber_0',['Grabber',['../classic4_1_1_grabber.html',1,'ic4']]]
];
