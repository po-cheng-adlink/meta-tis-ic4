var structic4_1_1_display_statistics =
[
    [ "num_frames_displayed", "structic4_1_1_display_statistics.html#ac9cd5dd300c6438c82021c0e2dc90be5", null ],
    [ "num_frames_dropped", "structic4_1_1_display_statistics.html#afcea9bf1389f82988d205a8d2d5f68a4", null ]
];