var searchData=
[
  ['reserved0_0',['reserved0',['../structic4_1_1_init_library_config.html#af739c5839fbc080ce2b6f70f24961d4b',1,'ic4::InitLibraryConfig']]],
  ['reversex_1',['ReverseX',['../namespaceic4_1_1_prop_id.html#a8265106fc94bd2f71f6e539cd523f9dd',1,'ic4::PropId']]],
  ['reversey_2',['ReverseY',['../namespaceic4_1_1_prop_id.html#ac03579c39dc685a4f49bc0027f57619b',1,'ic4::PropId']]]
];
