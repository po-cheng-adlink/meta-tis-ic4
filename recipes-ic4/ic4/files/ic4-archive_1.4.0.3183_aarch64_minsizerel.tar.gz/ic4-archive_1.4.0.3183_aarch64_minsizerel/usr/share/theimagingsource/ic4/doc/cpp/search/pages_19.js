var searchData=
[
  ['what_20s_20new_0',['What s New',['../whatsnew.html',1,'What&apos;s New'],['../index.html#main_whatsnew',1,'What's New']]],
  ['windows_1',['Windows',['../minimal_requirements.html#windows_requiremets',1,'Windows'],['../technical_article_distributing_your_applications.html#distribution_windows',1,'Windows']]]
];
