var structic4_1_1_init_library_config =
[
    [ "apiLogLevel", "structic4_1_1_init_library_config.html#a0565e256da9098564ec0aa6eab8f2762", null ],
    [ "defaultErrorHandlerBehavior", "structic4_1_1_init_library_config.html#a8acd7cb452aa42bd84300b54e919835a", null ],
    [ "internalLogLevel", "structic4_1_1_init_library_config.html#a4c782c74a9a51bfe4dd8a164fef405ff", null ],
    [ "logFilePath", "structic4_1_1_init_library_config.html#ae22136461a8511c472f1f662bd8f8fc3", null ],
    [ "logTargets", "structic4_1_1_init_library_config.html#aaa266979b61677b95cbb54c688c575dc", null ],
    [ "reserved0", "structic4_1_1_init_library_config.html#af739c5839fbc080ce2b6f70f24961d4b", null ]
];