var structic4_1_1_buffer_pool_1_1_cache_config =
[
    [ "bytes_max", "structic4_1_1_buffer_pool_1_1_cache_config.html#af8f75dc8a838ead62efe22e96cf2a164", null ],
    [ "frames_max", "structic4_1_1_buffer_pool_1_1_cache_config.html#ab3845919affaa37125c73eea5c3bdc42", null ]
];