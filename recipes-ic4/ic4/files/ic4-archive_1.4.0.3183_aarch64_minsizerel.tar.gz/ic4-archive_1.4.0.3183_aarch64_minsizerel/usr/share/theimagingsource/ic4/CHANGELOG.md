# Changelog

All notable changes to this project will be documented in this file.


## 1.4.0 - 2025 Aug 25

### Added

- Add Display::canRender function
- Add support for PollingTime in GenICam documents
- [C++] Add Error::throwAsIC4Exception

### Fixed

- Fix possible deadlock when trying to deserialize incompatible device properties

## 1.3.0 - 2025 Apr 28

### Added

- Add full screen mode to ic4-demoapp
- Add command line parameters to ic4-demoapp
- Add definitions for pixel formats of polarization cameras
- Include driver transform queue underrun counter to stream statistics
- [Windows] Add ARM64 binaries and build integration
- [Windows] Add version information to executables
- [.NET] Add PixelFormatExtensions.GetBitsPerPixel helper function
- [Python] Add ImageType.with_pixel_format and ImageType.with_size functions

### Changed

- Replace license aggreement with new IC4 EULA
- Aggregate third-party license information into a single file
- [Windows] The installation is now a pure per-user msi and does not need elevated priviliges
- [Windows] Restructure installation directory to make documentation more discoverable
- [C++] Add missing const qualifier to ic4::PropRegister::getValue
- [Python] PropRegister.value setter now also accepts values of type `bytes`

### Fixed

- Saved device state no longer contains unreachable features
- [.NET] Design mode detection now works if ic4.WinForms.Display is embedded inside a UserControl
- [C++] Fix unqualified use of nullptr_t in public header file
- [Python] Fix Display.set_render_position argument names and documentation

## 1.2.0 - 2024 Sep 30

### Added

- First release with Linux support
- Add support for saving images and video from image buffers with Y411 formats
- Add system info popup to ic4-demoapp's device selection dialog
- [Python, C++. .NET] Grabber constructor accepts optional DeviceInfo or device identifier.
- [Python] Add ic4.Library.init_context function
- [Python] Add imagingcontrol4pyside6 library, providing PropertyDialog and DeviceSelectionDialog
- [.NET] Add ExternalOpenGLDisplay

### Changed

- ic4-demoapp's device property dialog is now non-modal
- Grabber::saveDeviceState functions now also serialize driver settings
- [Python] imagingcontrol4's numpy dependency is now optional

### Fixed

- Possible race condition between propmap_find and prop_unref
- Saving a Mono16 ImageBuffer into a TIFF file modifies the buffer's contents
- ExternalOpenGLDisplay does not work correctly with OpenGL Core Profile
- [C++] ic4interop::Qt::DisplayWindow crashes when associated ic4::Display is destroyed first
- [C++] Mouse events do not work in ic4interop::Qt::DisplayWidget
- [Python] imagingcontrol4.pyside6.DisplayWidget crashes when associated ic4.Display is destroyed first
- [Python] Mouse events do not work in imagingcontrol4.pyside6.DisplayWidget
- [Python] imagingcontrol4.pyside6.DisplayWindow constructor does not work

## 1.1.0 - 2024 Jun 24 

### Added

- Renderer for external OpenGL Window
- Function to query library/driver versions
- PixelFormat convenience entries
- Support for specifying IPV4 address, MAC address as identifier when calling Grabber::deviceOpen
- Let PropertyMap::setValue functions accept display name of enumeration entries
- [C++] OpenCV interop library
- [C++] Qt interop library
- [C++] HALCON interop library
- [C++] QueueSink::create overloads taking std::function for framesQueued event
- [.NET] HALCON interop library
- [Python] PySide6 interop library
- [ic4-demoapp] Support for new driver features (e.g. USB driver switching) in device selection dialog

### Fixed

- Window title of floating display changed from 'Hello' to 'IC Imaging Control 4'
- Display not handling borders for bayer formats correctly
- Image buffers sometimes being dropped by unlucky scheduling
- [.NET] Error message sometimes not indicating the correct function

## 1.0.2 - 2024 May 16

### Fixed

- [.NET] Fix crash in DeviceLost event after garbage collection

## 1.0.1 - 2024 Jan 19

### Fixed

- [Python] Fix exception from Grabber.is_streaming

## 1.0.0 - 2023 Dec 15

Initial stable release for Windows
