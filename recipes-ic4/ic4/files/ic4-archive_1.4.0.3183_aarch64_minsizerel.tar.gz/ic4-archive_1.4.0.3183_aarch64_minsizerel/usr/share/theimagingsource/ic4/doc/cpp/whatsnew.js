var whatsnew =
[
    [ "Version History", "whatsnew.html#whatsnew_history", [
      [ "IC Imaging Control 4 Version 1.0", "whatsnew.html#changes_1_0", null ],
      [ "IC Imaging Control 4 Version 1.1", "whatsnew.html#changes_1_1", null ],
      [ "IC Imaging Control 4 Version 1.2", "whatsnew.html#changes_1_2", null ],
      [ "IC Imaging Control 4 Version 1.3", "whatsnew.html#changes_1_3", null ]
    ] ],
    [ "Transitioning from IC Imaging Control 3.x C++ Class Library", "whatsnew_from35.html", [
      [ "Differences between IC Imaging Control 3.x Class Library and IC Imaging Control 4 C++ Class Library", "whatsnew_from35.html#diff35", null ],
      [ "Transition Hints", "whatsnew_from35.html#transitionhints35", [
        [ "Familiar Concepts", "whatsnew_from35.html#familiarconcepts35", [
          [ "Grabber", "whatsnew_from35.html#familiarconcepts35grabber", null ]
        ] ],
        [ "Changed Concepts", "whatsnew_from35.html#changedconcepts35", [
          [ "Device Enumeration", "whatsnew_from35.html#changedconcepts35devenum", null ],
          [ "Device Properties", "whatsnew_from35.html#changedconcepts35properties", null ],
          [ "Video Formats, Video Norms, Frame Rates", "whatsnew_from35.html#changedconcepts35formats", null ],
          [ "Video Files", "whatsnew_from35.html#changedconcepts35video", null ],
          [ "Display", "whatsnew_from35.html#changedconcepts35display", null ]
        ] ],
        [ "Renamed Concepts", "whatsnew_from35.html#rewording35", [
          [ "Live Mode", "whatsnew_from35.html#rewording35live", null ],
          [ "Data Types", "whatsnew_from35.html#Renamed", null ],
          [ "Property API", "whatsnew_from35.html#New", null ]
        ] ]
      ] ]
    ] ]
];