var searchData=
[
  ['2_0',['IC Imaging Control4 Version 1.2',['../whatsnew.html#changes_1_2',1,'']]]
];
