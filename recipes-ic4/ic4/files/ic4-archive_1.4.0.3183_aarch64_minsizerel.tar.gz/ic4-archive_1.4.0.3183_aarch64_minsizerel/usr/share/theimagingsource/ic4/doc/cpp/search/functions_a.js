var searchData=
[
  ['name_0',['name',['../classic4_1_1_property.html#a93649c939bf1abead63f512f725cd71e',1,'ic4::Property']]],
  ['notifywindowclosed_1',['notifyWindowClosed',['../classic4_1_1_external_open_g_l_display.html#a8f9ce07dc7db4d0d32caa5ef6f63bc14',1,'ic4::ExternalOpenGLDisplay']]]
];
