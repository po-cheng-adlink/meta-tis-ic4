var structic4_1_1_save_jpeg_options =
[
    [ "quality_pct", "structic4_1_1_save_jpeg_options.html#af573731d28103c8932b331c88b2c1997", null ]
];