var classic4_1_1_external_open_g_l_display =
[
    [ "initialize", "classic4_1_1_external_open_g_l_display.html#a84dcb820f04d494f65881d86b6f2e351", null ],
    [ "notifyWindowClosed", "classic4_1_1_external_open_g_l_display.html#a8f9ce07dc7db4d0d32caa5ef6f63bc14", null ],
    [ "render", "classic4_1_1_external_open_g_l_display.html#aa1ecf63edd9a2363fee061acb0b5a639", null ]
];