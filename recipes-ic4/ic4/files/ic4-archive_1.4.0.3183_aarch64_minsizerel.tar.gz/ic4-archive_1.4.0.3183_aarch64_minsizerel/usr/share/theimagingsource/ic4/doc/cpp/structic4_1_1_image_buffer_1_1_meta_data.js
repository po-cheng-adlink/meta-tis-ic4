var structic4_1_1_image_buffer_1_1_meta_data =
[
    [ "device_frame_number", "structic4_1_1_image_buffer_1_1_meta_data.html#a1e111673ebc53c5f4118562d87487ced", null ],
    [ "device_timestamp_ns", "structic4_1_1_image_buffer_1_1_meta_data.html#a3ffd50c722ad4a9a82f9d3faa820abb4", null ]
];