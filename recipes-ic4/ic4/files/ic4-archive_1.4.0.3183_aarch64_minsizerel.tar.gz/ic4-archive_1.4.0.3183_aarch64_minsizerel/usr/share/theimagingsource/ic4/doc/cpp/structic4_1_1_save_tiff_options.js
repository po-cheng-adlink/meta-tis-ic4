var structic4_1_1_save_tiff_options =
[
    [ "store_raw_bayer_data_as_monochrome", "structic4_1_1_save_tiff_options.html#a746996e64254362c0eafb77085bb23eb", null ]
];