var searchData=
[
  ['quality_5fpct_1029',['quality_pct',['../struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___j_p_e_g.html#af573731d28103c8932b331c88b2c1997',1,'IC4_IMAGEBUFFER_SAVE_OPTIONS_JPEG']]]
];
