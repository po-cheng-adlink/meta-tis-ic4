var searchData=
[
  ['grabber_1246',['Grabber',['../group__grabber.html',1,'']]],
  ['graphical_20user_20interface_20functions_1247',['Graphical User Interface Functions',['../group__ic4gui.html',1,'']]]
];
