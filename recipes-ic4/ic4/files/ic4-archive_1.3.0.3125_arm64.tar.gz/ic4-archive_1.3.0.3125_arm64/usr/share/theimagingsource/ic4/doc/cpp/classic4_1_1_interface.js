var classic4_1_1_interface =
[
    [ "Interface", "classic4_1_1_interface.html#a6e2edf40c996b33d6eeab977f74d232d", null ],
    [ "enumDevices", "classic4_1_1_interface.html#a20a89ca45eb6f4b3dcd4ca63a9b2cd53", null ],
    [ "interfaceDisplayName", "classic4_1_1_interface.html#aa0a63f6aa5c914a3bbf6e1f4f41f16ce", null ],
    [ "interfacePropertyMap", "classic4_1_1_interface.html#a15be1c0f4395284a7a33ddd9d631f7fc", null ],
    [ "is_valid", "classic4_1_1_interface.html#a8f3163cdc2ec7303fd4be1854f4f931e", null ],
    [ "operator!=", "classic4_1_1_interface.html#a39e3b69a2fd90c2422e2940287444b87", null ],
    [ "operator==", "classic4_1_1_interface.html#a01278389efee44a574b499e5f26161cf", null ],
    [ "transportLayerName", "classic4_1_1_interface.html#a5a28900d4c5928102b1f90cbfff41269", null ],
    [ "transportLayerType", "classic4_1_1_interface.html#a3755dfd0f4e70a24f7dbd0b996c12855", null ],
    [ "transportLayerVersion", "classic4_1_1_interface.html#aa60310acc11943d6194b4e89dbcb0049", null ]
];