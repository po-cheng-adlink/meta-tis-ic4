var group__snapsink =
[
    [ "IC4_SNAPSINK_CONFIG", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html", [
      [ "allocator", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0", null ],
      [ "allocator_context", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b", null ],
      [ "num_buffers_alloc_on_connect", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ae7652505d77b3dddd05d0de05f83aa9f", null ],
      [ "num_buffers_allocation_threshold", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ab2ffd6fd78a9f7f66614ff6dfa4bb962", null ],
      [ "num_buffers_free_threshold", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a61db113746532d34085b650bda9cf2c7", null ],
      [ "num_buffers_max", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a12fbf2c094cff7313d39854d8da7ed75", null ],
      [ "num_pixel_formats", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a2338263a6d8a06f84b6fedae9ba223eb", null ],
      [ "pixel_formats", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284", null ],
      [ "strategy", "struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ac639b850ad494728dc5d0f914aa6e526", null ]
    ] ],
    [ "IC4_SNAPSINK_ALLOCATION_STRATEGY", "group__snapsink.html#gabf764a313f789774571ae7a2b8231ce0", [
      [ "IC4_SNAPSINK_ALLOCATION_STRATEGY_DEFAULT", "group__snapsink.html#ggabf764a313f789774571ae7a2b8231ce0ac04f636b04c120b7804ddce605b8a15e", null ],
      [ "IC4_SNAPSINK_ALLOCATION_STRATEGY_CUSTOM", "group__snapsink.html#ggabf764a313f789774571ae7a2b8231ce0a19c00563d36e918a7f4e7c1143115acb", null ]
    ] ],
    [ "ic4_snapsink_create", "group__snapsink.html#ga8ff11faa66e610c2be5db1a1f656258f", null ],
    [ "ic4_snapsink_get_output_image_type", "group__snapsink.html#gaa7a3c55518ca47b1c07b7b6b435bf96f", null ],
    [ "ic4_snapsink_snap_sequence", "group__snapsink.html#ga699579a39b40d6ed6cef6789b9ebd2db", null ],
    [ "ic4_snapsink_snap_single", "group__snapsink.html#gad870fdeae26e939dc7dc1948038321dd", null ]
];