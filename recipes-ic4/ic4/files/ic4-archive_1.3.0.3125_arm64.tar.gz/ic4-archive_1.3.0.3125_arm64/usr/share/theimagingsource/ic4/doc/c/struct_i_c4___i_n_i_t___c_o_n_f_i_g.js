var struct_i_c4___i_n_i_t___c_o_n_f_i_g =
[
    [ "api_log_level", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#ac2e2c614ceb71c230bfa6b0b89b8476c", null ],
    [ "internal_log_level", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#abe396c0692242978c0346ef65c5ca1c9", null ],
    [ "log_file", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#aeee7252e51523f7c2fd39151ae7eaf05", null ],
    [ "log_targets", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#abe17511a4b5c176ab3c9f2c67a4ab8f2", null ],
    [ "reserved0", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#af739c5839fbc080ce2b6f70f24961d4b", null ]
];