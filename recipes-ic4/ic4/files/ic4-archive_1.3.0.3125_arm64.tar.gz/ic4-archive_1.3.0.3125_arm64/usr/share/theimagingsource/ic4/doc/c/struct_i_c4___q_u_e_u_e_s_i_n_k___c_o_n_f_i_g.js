var struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g =
[
    [ "allocator", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0", null ],
    [ "allocator_context", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b", null ],
    [ "callback_context", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a67b5953b36108e04f24abe803bc1fe44", null ],
    [ "callbacks", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a10d41ab705ab975fa6266a447881b614", null ],
    [ "max_output_buffers", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a493a1c228d64efe0f3eace7718ce3920", null ],
    [ "num_pixel_formats", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a2338263a6d8a06f84b6fedae9ba223eb", null ],
    [ "pixel_formats", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284", null ]
];