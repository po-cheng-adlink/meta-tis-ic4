var searchData=
[
  ['accessing_20device_20properties_1262',['Accessing Device Properties',['../technical_article_properties.html',1,'technical_articles']]]
];
