var group__regprop =
[
    [ "ic4_prop_register_get_size", "group__regprop.html#ga0682934d1db4edb9a9a49c5dc32c38f0", null ],
    [ "ic4_prop_register_get_value", "group__regprop.html#gaa12b12aa028d185b3c53bda75616e420", null ],
    [ "ic4_prop_register_set_value", "group__regprop.html#ga2dabeb33c967e89ec3263a99d035aa82", null ]
];