var classic4_1_1_buffer_pool =
[
    [ "AllocationOptions", "structic4_1_1_buffer_pool_1_1_allocation_options.html", "structic4_1_1_buffer_pool_1_1_allocation_options" ],
    [ "CacheConfig", "structic4_1_1_buffer_pool_1_1_cache_config.html", "structic4_1_1_buffer_pool_1_1_cache_config" ],
    [ "getBuffer", "classic4_1_1_buffer_pool.html#a02fe5cd4c4e53a176ab075d5a9367acb", null ],
    [ "getBuffer", "classic4_1_1_buffer_pool.html#aefc17a260705acf297163f4308e43042", null ]
];