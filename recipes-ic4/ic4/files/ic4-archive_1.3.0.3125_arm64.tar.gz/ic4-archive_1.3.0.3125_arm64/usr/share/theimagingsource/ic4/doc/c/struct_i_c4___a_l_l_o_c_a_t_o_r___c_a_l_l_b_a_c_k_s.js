var struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s =
[
    [ "allocate_buffer", "struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a7c874c743f3096e3bed1626e11f8c0b8", null ],
    [ "free_buffer", "struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a6dd0eb431f10623994698200c7037355", null ],
    [ "release", "struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8", null ]
];