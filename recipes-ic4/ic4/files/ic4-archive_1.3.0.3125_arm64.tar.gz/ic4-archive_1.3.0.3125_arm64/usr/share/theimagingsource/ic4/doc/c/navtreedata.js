/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Imaging Control 4 C Library", "index.html", [
    [ "Introduction", "index.html", [
      [ "What's New", "index.html#main_whatsnew", null ],
      [ "Programmer's Guide", "index.html#main_programmers_guide", null ],
      [ "Technical Articles", "index.html#main_technical", null ],
      [ "API Reference", "index.html#mainpage_api_reference", null ],
      [ "Example Programs", "index.html#mainpage_example_programs", null ]
    ] ],
    [ "What's New", "whatsnew.html", "whatsnew" ],
    [ "Programmer's Guide", "programmers_guide.html", "programmers_guide" ],
    [ "Technical Articles", "technical_articles.html", "technical_articles" ],
    [ "Example Programs", "example_programs.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group__imgbuf.html#gga8320349d4efa8d8b7042f79d153359b4ad83e83db022e1b0903d7b105b338e9da",
"group__propid.html#gaea6011a413e70ebb7234bcde1f228bfd",
"struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';