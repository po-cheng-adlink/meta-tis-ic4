var struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s =
[
    [ "alignment", "struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a3afda29223eeda35afd21a6c5e121ba2", null ],
    [ "buffer_size", "struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a799a743b3abd553a37fc01ad3097df08", null ],
    [ "pitch", "struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a8b9619114eefd65cd8c9804ad6154215", null ]
];