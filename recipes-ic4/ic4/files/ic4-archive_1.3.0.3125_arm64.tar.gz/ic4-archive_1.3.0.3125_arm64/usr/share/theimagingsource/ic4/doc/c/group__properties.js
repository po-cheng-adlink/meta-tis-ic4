var group__properties =
[
    [ "Property Map", "group__propmap.html", "group__propmap" ],
    [ "Property Objects", "group__propobj.html", "group__propobj" ],
    [ "Property Lists", "group__proplist.html", "group__proplist" ],
    [ "Property Identifiers", "group__propid.html", "group__propid" ]
];