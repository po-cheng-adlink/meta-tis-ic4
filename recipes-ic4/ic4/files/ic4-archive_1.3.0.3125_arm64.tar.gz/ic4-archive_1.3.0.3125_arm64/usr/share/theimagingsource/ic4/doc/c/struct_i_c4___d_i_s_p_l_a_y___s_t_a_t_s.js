var struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s =
[
    [ "num_frames_displayed", "struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#ac9cd5dd300c6438c82021c0e2dc90be5", null ],
    [ "num_frames_dropped", "struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#afcea9bf1389f82988d205a8d2d5f68a4", null ]
];