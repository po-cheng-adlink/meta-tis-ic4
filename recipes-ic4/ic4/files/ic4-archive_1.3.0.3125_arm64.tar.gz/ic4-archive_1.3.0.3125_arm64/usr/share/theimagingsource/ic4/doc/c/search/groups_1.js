var searchData=
[
  ['category_20properties_1238',['Category Properties',['../group__catprop.html',1,'']]],
  ['command_20properties_1239',['Command Properties',['../group__cmdprop.html',1,'']]],
  ['core_20library_20functions_1240',['Core Library Functions',['../group__library.html',1,'']]]
];
