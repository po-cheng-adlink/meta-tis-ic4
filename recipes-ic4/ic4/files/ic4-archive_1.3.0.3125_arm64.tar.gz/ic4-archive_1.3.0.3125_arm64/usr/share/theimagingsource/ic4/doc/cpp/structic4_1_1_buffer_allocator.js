var structic4_1_1_buffer_allocator =
[
    [ "~BufferAllocator", "structic4_1_1_buffer_allocator.html#ae1a2ea61c0c042a96037dc62b4c96d08", null ],
    [ "allocate_buffer", "structic4_1_1_buffer_allocator.html#a84e0029930aec1985051f99556a39655", null ],
    [ "free_buffer", "structic4_1_1_buffer_allocator.html#a135a1d69651a9acce8c8d2922cdb1a67", null ]
];