var struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___t_i_f_f =
[
    [ "store_bayer_raw_data_as_monochrome", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___t_i_f_f.html#a8e11af713954f39b9f386d9d5cbd41d5", null ]
];