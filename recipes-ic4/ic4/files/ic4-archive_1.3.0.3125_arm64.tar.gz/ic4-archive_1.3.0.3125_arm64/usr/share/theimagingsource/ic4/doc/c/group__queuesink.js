var group__queuesink =
[
    [ "IC4_QUEUESINK_CALLBACKS", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html", [
      [ "frames_queued", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a767a7af3c0252bcfec7a26629d38cfeb", null ],
      [ "release", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8", null ],
      [ "sink_connected", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#abf6ba871c9b60106378498ad202ee885", null ],
      [ "sink_disconnected", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a6af4ff55b37bd5127050ee997107eb7c", null ]
    ] ],
    [ "IC4_QUEUESINK_CONFIG", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html", [
      [ "allocator", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0", null ],
      [ "allocator_context", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b", null ],
      [ "callback_context", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a67b5953b36108e04f24abe803bc1fe44", null ],
      [ "callbacks", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a10d41ab705ab975fa6266a447881b614", null ],
      [ "max_output_buffers", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a493a1c228d64efe0f3eace7718ce3920", null ],
      [ "num_pixel_formats", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a2338263a6d8a06f84b6fedae9ba223eb", null ],
      [ "pixel_formats", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284", null ]
    ] ],
    [ "IC4_QUEUESINK_QUEUE_SIZES", "struct_i_c4___q_u_e_u_e_s_i_n_k___q_u_e_u_e___s_i_z_e_s.html", [
      [ "free_queue_length", "struct_i_c4___q_u_e_u_e_s_i_n_k___q_u_e_u_e___s_i_z_e_s.html#ac86292452a5be9525a58b73a40354abf", null ],
      [ "output_queue_length", "struct_i_c4___q_u_e_u_e_s_i_n_k___q_u_e_u_e___s_i_z_e_s.html#abeddbceb1598ad07d061a33d1e00927d", null ]
    ] ],
    [ "ic4_queuesink_alloc_and_queue_buffers", "group__queuesink.html#ga535d74e78dfe9d84d9d03bba59646505", null ],
    [ "ic4_queuesink_create", "group__queuesink.html#gafb05a00746453a84f9be27633994c385", null ],
    [ "ic4_queuesink_get_output_image_type", "group__queuesink.html#ga2cafa6599d063a1a7dd5c1d4c326c7a6", null ],
    [ "ic4_queuesink_get_queue_sizes", "group__queuesink.html#ga2e7b9d859f0f7e4caf20508a180bbf14", null ],
    [ "ic4_queuesink_is_cancel_requested", "group__queuesink.html#ga5ecad7575c7d3c1da06a61eacf7c7a0f", null ],
    [ "ic4_queuesink_pop_output_buffer", "group__queuesink.html#gac041e87318da29b869ffe06816bb3796", null ]
];