var searchData=
[
  ['saving_20images_730',['Saving Images',['../group__saveimages.html',1,'']]],
  ['sinks_731',['Sinks',['../group__sink.html',1,'']]],
  ['sink_5fconnected_732',['sink_connected',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#abf6ba871c9b60106378498ad202ee885',1,'IC4_QUEUESINK_CALLBACKS']]],
  ['sink_5fdelivered_733',['sink_delivered',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#a673e9a1d04f627c29566c03786acdb32',1,'IC4_STREAM_STATS::sink_delivered()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#a673e9a1d04f627c29566c03786acdb32',1,'IC4_STREAM_STATS_V2::sink_delivered()']]],
  ['sink_5fdisconnected_734',['sink_disconnected',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a6af4ff55b37bd5127050ee997107eb7c',1,'IC4_QUEUESINK_CALLBACKS']]],
  ['sink_5fignored_735',['sink_ignored',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#af3bb58455258708a592040f6de679ef9',1,'IC4_STREAM_STATS::sink_ignored()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#af3bb58455258708a592040f6de679ef9',1,'IC4_STREAM_STATS_V2::sink_ignored()']]],
  ['sink_5funderrun_736',['sink_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ac57952db1e7a91bebd90906cc686d87d',1,'IC4_STREAM_STATS::sink_underrun()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ac57952db1e7a91bebd90906cc686d87d',1,'IC4_STREAM_STATS_V2::sink_underrun()']]],
  ['snap_20sink_737',['Snap Sink',['../group__snapsink.html',1,'']]],
  ['store_5fbayer_5fraw_5fdata_5fas_5fmonochrome_738',['store_bayer_raw_data_as_monochrome',['../struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___b_m_p.html#a8e11af713954f39b9f386d9d5cbd41d5',1,'IC4_IMAGEBUFFER_SAVE_OPTIONS_BMP::store_bayer_raw_data_as_monochrome()'],['../struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___p_n_g.html#a8e11af713954f39b9f386d9d5cbd41d5',1,'IC4_IMAGEBUFFER_SAVE_OPTIONS_PNG::store_bayer_raw_data_as_monochrome()'],['../struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___t_i_f_f.html#a8e11af713954f39b9f386d9d5cbd41d5',1,'IC4_IMAGEBUFFER_SAVE_OPTIONS_TIFF::store_bayer_raw_data_as_monochrome()']]],
  ['strategy_739',['strategy',['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ac639b850ad494728dc5d0f914aa6e526',1,'IC4_SNAPSINK_CONFIG']]],
  ['string_20properties_740',['String Properties',['../group__stringprop.html',1,'']]]
];
