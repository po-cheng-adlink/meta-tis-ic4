var searchData=
[
  ['minimal_20requirements_1273',['Minimal Requirements',['../minimal_requirements.html',1,'programmers_guide']]]
];
