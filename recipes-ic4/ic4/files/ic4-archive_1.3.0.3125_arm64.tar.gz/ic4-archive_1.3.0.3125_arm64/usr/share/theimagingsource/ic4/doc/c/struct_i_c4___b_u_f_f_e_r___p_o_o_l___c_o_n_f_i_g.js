var struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g =
[
    [ "allocator", "struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0", null ],
    [ "allocator_context", "struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b", null ],
    [ "cache_bytes_max", "struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#ae938b780ec8f759168ee82247b22870d", null ],
    [ "cache_frames_max", "struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a639c541ea330c5a9681a629bca06b1a5", null ]
];