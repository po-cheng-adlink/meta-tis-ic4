var struct_i_c4___s_t_r_e_a_m___s_t_a_t_s =
[
    [ "device_delivered", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ab62d16cc71398e9362feb3320b4705cb", null ],
    [ "device_transmission_error", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ad6c254ea67852baa501a3758861aa871", null ],
    [ "device_underrun", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ae8447e6f4ed71ef03da194f914b48190", null ],
    [ "sink_delivered", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#a673e9a1d04f627c29566c03786acdb32", null ],
    [ "sink_ignored", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#af3bb58455258708a592040f6de679ef9", null ],
    [ "sink_underrun", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ac57952db1e7a91bebd90906cc686d87d", null ],
    [ "transform_delivered", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#a24a49808b1a533ddc8c81ef9d8af49d1", null ],
    [ "transform_underrun", "struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ad47903278206a6937c8b9d4bde7613a4", null ]
];