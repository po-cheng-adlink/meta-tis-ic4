var classic4interop_1_1_qt_1_1_display_widget =
[
    [ "DisplayWidget", "classic4interop_1_1_qt_1_1_display_widget.html#a04f3a614fc85beca53a972fb4e11252a", null ],
    [ "asDisplay", "classic4interop_1_1_qt_1_1_display_widget.html#add37d4c48b45d33fd49cb29d252bdc8a", null ]
];