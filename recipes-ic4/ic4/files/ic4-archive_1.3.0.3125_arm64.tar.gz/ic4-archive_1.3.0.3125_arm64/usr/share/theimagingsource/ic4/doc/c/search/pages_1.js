var searchData=
[
  ['configuring_20a_20video_20capture_20device_1263',['Configuring a Video Capture Device',['../guide_configuring_device.html',1,'programmers_guide']]]
];
