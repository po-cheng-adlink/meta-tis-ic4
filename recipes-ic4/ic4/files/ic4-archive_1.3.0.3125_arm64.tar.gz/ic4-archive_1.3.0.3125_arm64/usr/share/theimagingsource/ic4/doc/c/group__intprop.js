var group__intprop =
[
    [ "IC4_PROPERTY_INT_REPRESENTATION", "group__intprop.html#ga4643fe43a1febf0d08f5d45e01a01418", [
      [ "IC4_PROPINTREP_LINEAR", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a50e18368beecb5535e214e79581fe4d1", null ],
      [ "IC4_PROPINTREP_LOGARITHMIC", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a0d328f21aea35cf8363ca628e1467aa8", null ],
      [ "IC4_PROPINTREP_BOOLEAN", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418af3c03267e7bae5b8fed7ba01c99a7ffd", null ],
      [ "IC4_PROPINTREP_PURENUMBER", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a52b1eaf453c051f6f3c80cc4576be898", null ],
      [ "IC4_PROPINTREP_HEXNUMBER", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a94dad359eb20194e5477807994f5edcf", null ],
      [ "IC4_PROPINTREP_IPV4ADDRESS", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a9e9d8640e9c4be6c1b36f8c6518bdf4e", null ],
      [ "IC4_PROPINTREP_MACADDRESS", "group__intprop.html#gga4643fe43a1febf0d08f5d45e01a01418a0132f40e287707860ed0fb2e5402953c", null ]
    ] ],
    [ "ic4_prop_integer_get_inc", "group__intprop.html#ga43b86ba0f81c4282551081fcc78dfa7c", null ],
    [ "ic4_prop_integer_get_inc_mode", "group__intprop.html#ga6c8ac5c9cf03405738e23a55b8736296", null ],
    [ "ic4_prop_integer_get_max", "group__intprop.html#ga734c15c524bd3217666776d7351b9d1b", null ],
    [ "ic4_prop_integer_get_min", "group__intprop.html#ga5560f4bcde5374b975b3b967f846d693", null ],
    [ "ic4_prop_integer_get_representation", "group__intprop.html#gab48c9143ce24b850631fc9ed71726590", null ],
    [ "ic4_prop_integer_get_unit", "group__intprop.html#ga966d181bf3e8a3cf7c0b3f721a429e99", null ],
    [ "ic4_prop_integer_get_valid_value_set", "group__intprop.html#ga8d2ac266a4429a8eaf814f8c24702394", null ],
    [ "ic4_prop_integer_get_value", "group__intprop.html#gaf827b323e1b611afc6bd0b810919997e", null ],
    [ "ic4_prop_integer_set_value", "group__intprop.html#ga7dded899e60d36d577efedce4800f94c", null ]
];