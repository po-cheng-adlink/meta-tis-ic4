var searchData=
[
  ['saving_20images_1257',['Saving Images',['../group__saveimages.html',1,'']]],
  ['sinks_1258',['Sinks',['../group__sink.html',1,'']]],
  ['snap_20sink_1259',['Snap Sink',['../group__snapsink.html',1,'']]],
  ['string_20properties_1260',['String Properties',['../group__stringprop.html',1,'']]]
];
