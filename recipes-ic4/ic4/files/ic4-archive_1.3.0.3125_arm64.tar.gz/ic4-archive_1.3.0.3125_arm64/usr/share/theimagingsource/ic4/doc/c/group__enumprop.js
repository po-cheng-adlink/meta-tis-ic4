var group__enumprop =
[
    [ "ic4_prop_enum_find_entry_by_name", "group__enumprop.html#ga61983d3bc9263ee1514893ccba8a46e1", null ],
    [ "ic4_prop_enum_find_entry_by_value", "group__enumprop.html#ga866588819d60ed8c01e3a097521045a9", null ],
    [ "ic4_prop_enum_get_entries", "group__enumprop.html#ga4fc99881699fc173ea0e7d39ddcfc8f3", null ],
    [ "ic4_prop_enum_get_int_value", "group__enumprop.html#ga723a1477384c89bdc054064c530d32c4", null ],
    [ "ic4_prop_enum_get_selected_entry", "group__enumprop.html#ga82b21f30bd7c90b0a4b68d0ef4ed61de", null ],
    [ "ic4_prop_enum_get_value", "group__enumprop.html#ga8aa740cd8fd75a1cc6f38893b2a12004", null ],
    [ "ic4_prop_enum_set_int_value", "group__enumprop.html#ga263885c6551aba3cec29f8bb95094245", null ],
    [ "ic4_prop_enum_set_selected_entry", "group__enumprop.html#ga26b8c97edb10edf8a7b745adf00d423c", null ],
    [ "ic4_prop_enum_set_value", "group__enumprop.html#gaf24ad82936caff190f26649943ae70c5", null ],
    [ "ic4_prop_enumentry_get_int_value", "group__enumprop.html#ga02765e92af361f2ebdd71022fdf9b1f4", null ]
];