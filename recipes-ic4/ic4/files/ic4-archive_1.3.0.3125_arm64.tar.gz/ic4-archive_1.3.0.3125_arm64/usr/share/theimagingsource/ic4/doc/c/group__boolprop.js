var group__boolprop =
[
    [ "ic4_prop_boolean_get_value", "group__boolprop.html#gaf142194aece9d7eb3d981e9ed6d687f3", null ],
    [ "ic4_prop_boolean_set_value", "group__boolprop.html#ga9fab1e27f0caf1d39afba610ac6420e0", null ]
];