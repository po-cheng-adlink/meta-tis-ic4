var searchData=
[
  ['max_5foutput_5fbuffers_706',['max_output_buffers',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a493a1c228d64efe0f3eace7718ce3920',1,'IC4_QUEUESINK_CONFIG']]],
  ['minimal_20requirements_707',['Minimal Requirements',['../minimal_requirements.html',1,'programmers_guide']]]
];
