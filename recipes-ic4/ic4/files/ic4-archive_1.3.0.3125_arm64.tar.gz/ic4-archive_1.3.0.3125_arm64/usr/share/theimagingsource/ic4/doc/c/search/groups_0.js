var searchData=
[
  ['boolean_20properties_1237',['Boolean Properties',['../group__boolprop.html',1,'']]]
];
