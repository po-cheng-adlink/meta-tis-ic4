var searchData=
[
  ['num_5fbuffers_5falloc_5fon_5fconnect_708',['num_buffers_alloc_on_connect',['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ae7652505d77b3dddd05d0de05f83aa9f',1,'IC4_SNAPSINK_CONFIG']]],
  ['num_5fbuffers_5fallocation_5fthreshold_709',['num_buffers_allocation_threshold',['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ab2ffd6fd78a9f7f66614ff6dfa4bb962',1,'IC4_SNAPSINK_CONFIG']]],
  ['num_5fbuffers_5ffree_5fthreshold_710',['num_buffers_free_threshold',['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a61db113746532d34085b650bda9cf2c7',1,'IC4_SNAPSINK_CONFIG']]],
  ['num_5fbuffers_5fmax_711',['num_buffers_max',['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a12fbf2c094cff7313d39854d8da7ed75',1,'IC4_SNAPSINK_CONFIG']]],
  ['num_5fframes_5fdisplayed_712',['num_frames_displayed',['../struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#ac9cd5dd300c6438c82021c0e2dc90be5',1,'IC4_DISPLAY_STATS']]],
  ['num_5fframes_5fdropped_713',['num_frames_dropped',['../struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#afcea9bf1389f82988d205a8d2d5f68a4',1,'IC4_DISPLAY_STATS']]],
  ['num_5fpixel_5fformats_714',['num_pixel_formats',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a2338263a6d8a06f84b6fedae9ba223eb',1,'IC4_QUEUESINK_CONFIG::num_pixel_formats()'],['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a2338263a6d8a06f84b6fedae9ba223eb',1,'IC4_SNAPSINK_CONFIG::num_pixel_formats()']]]
];
