var classic4_1_1_image_buffer =
[
    [ "MetaData", "structic4_1_1_image_buffer_1_1_meta_data.html", "structic4_1_1_image_buffer_1_1_meta_data" ],
    [ "ReleaseMemoryHandler", "classic4_1_1_image_buffer.html#ac5ce8ac105f748145c05a5b2358605cb", null ],
    [ "CopyOptions", "classic4_1_1_image_buffer.html#ad68f7e5a19741c8fc9508e25a9efc4ca", [
      [ "Default", "classic4_1_1_image_buffer.html#ad68f7e5a19741c8fc9508e25a9efc4caa7a1920d61156abc05a60135aefe8bc67", null ],
      [ "SkipImage", "classic4_1_1_image_buffer.html#ad68f7e5a19741c8fc9508e25a9efc4caa629e85d8aa1b6c2ed48d2260366483ae", null ],
      [ "SkipChunkData", "classic4_1_1_image_buffer.html#ad68f7e5a19741c8fc9508e25a9efc4caaeb72b61a795858adac961baf2b4e2537", null ]
    ] ],
    [ "bufferSize", "classic4_1_1_image_buffer.html#a4c3e37542426405f81219481c3471ab4", null ],
    [ "copyFrom", "classic4_1_1_image_buffer.html#ad48a8f11072273c9b5e17d9543c2bbad", null ],
    [ "imageType", "classic4_1_1_image_buffer.html#a6f845cc01c184addc7b71e334b8ca92f", null ],
    [ "isWritable", "classic4_1_1_image_buffer.html#a85e799a990b59dd38f79cd2021e6d9c4", null ],
    [ "metaData", "classic4_1_1_image_buffer.html#afd255680210a94c17e806037118cb26a", null ],
    [ "pitch", "classic4_1_1_image_buffer.html#a3b72ba572deec6c7a7be7527355bd8e4", null ],
    [ "ptr", "classic4_1_1_image_buffer.html#a2e0ba911bfb3ebb21a970d32edde385d", null ]
];