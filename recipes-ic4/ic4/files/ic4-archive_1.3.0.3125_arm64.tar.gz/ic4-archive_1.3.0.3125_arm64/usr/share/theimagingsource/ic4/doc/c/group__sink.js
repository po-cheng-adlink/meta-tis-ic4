var group__sink =
[
    [ "Queue Sink", "group__queuesink.html", "group__queuesink" ],
    [ "Snap Sink", "group__snapsink.html", "group__snapsink" ],
    [ "IC4_SINK", "struct_i_c4___s_i_n_k.html", null ],
    [ "IC4_SINK_MODE", "group__sink.html#ga3a6e77dbcc593ce33cedd9dac6cdc845", [
      [ "IC4_SINK_MODE_RUN", "group__sink.html#gga3a6e77dbcc593ce33cedd9dac6cdc845a13e95a027cf303ca29b57f449fb90a3d", null ],
      [ "IC4_SINK_MODE_PAUSE", "group__sink.html#gga3a6e77dbcc593ce33cedd9dac6cdc845aaafa040db1b8f5e4a3075ebef04ebd2c", null ],
      [ "IC4_SINK_MODE_INVALID", "group__sink.html#gga3a6e77dbcc593ce33cedd9dac6cdc845ab7a0ed190067e50673dc850cacda9a51", null ]
    ] ],
    [ "IC4_SINK_TYPE", "group__sink.html#gae399e778e87b7c44ca4a074539b3f4cf", [
      [ "IC4_SINK_TYPE_QUEUESINK", "group__sink.html#ggae399e778e87b7c44ca4a074539b3f4cface21c9a150b7db0d9e43dec69c96145d", null ],
      [ "IC4_SINK_TYPE_SNAPSINK", "group__sink.html#ggae399e778e87b7c44ca4a074539b3f4cfaa84f6e0535274f4b5dd7e4ef70a9541b", null ],
      [ "IC4_SINK_TYPE_INVALID", "group__sink.html#ggae399e778e87b7c44ca4a074539b3f4cfaf094a27b85612f82d151979cd127d2a5", null ]
    ] ],
    [ "ic4_sink_get_mode", "group__sink.html#ga6fa14efed1b63adee41774170a9f415a", null ],
    [ "ic4_sink_get_type", "group__sink.html#gaaa3895b687b65960b01dc79177f169d5", null ],
    [ "ic4_sink_is_attached", "group__sink.html#gadb5ef7ff748d5ab128b9784d9bc8e045", null ],
    [ "ic4_sink_ref", "group__sink.html#gade57f65bf1b6e05f7b3d5be58f2f2692", null ],
    [ "ic4_sink_set_mode", "group__sink.html#gac8279a2c6d2cbbb42277c238500b8b1d", null ],
    [ "ic4_sink_unref", "group__sink.html#ga245bb679c026891bf14043086b73349d", null ]
];