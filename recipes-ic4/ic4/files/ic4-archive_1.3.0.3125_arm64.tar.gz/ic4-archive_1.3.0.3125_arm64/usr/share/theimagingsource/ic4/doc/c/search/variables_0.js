var searchData=
[
  ['alignment_989',['alignment',['../struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a3afda29223eeda35afd21a6c5e121ba2',1,'IC4_BUFFERPOOL_ALLOCATION_OPTIONS']]],
  ['allocate_5fbuffer_990',['allocate_buffer',['../struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a7c874c743f3096e3bed1626e11f8c0b8',1,'IC4_ALLOCATOR_CALLBACKS']]],
  ['allocator_991',['allocator',['../struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0',1,'IC4_BUFFER_POOL_CONFIG::allocator()'],['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0',1,'IC4_QUEUESINK_CONFIG::allocator()'],['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a4814312eb4b053e4ca9e1d25916e8bb0',1,'IC4_SNAPSINK_CONFIG::allocator()']]],
  ['allocator_5fcontext_992',['allocator_context',['../struct_i_c4___b_u_f_f_e_r___p_o_o_l___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b',1,'IC4_BUFFER_POOL_CONFIG::allocator_context()'],['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b',1,'IC4_QUEUESINK_CONFIG::allocator_context()'],['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#a7b884170b175a56b7817a9fd1ed0691b',1,'IC4_SNAPSINK_CONFIG::allocator_context()']]],
  ['api_5flog_5flevel_993',['api_log_level',['../struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#ac2e2c614ceb71c230bfa6b0b89b8476c',1,'IC4_INIT_CONFIG']]]
];
