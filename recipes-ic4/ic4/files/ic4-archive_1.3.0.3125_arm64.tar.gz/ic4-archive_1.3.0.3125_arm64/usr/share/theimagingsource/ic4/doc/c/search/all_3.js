var searchData=
[
  ['device_20enumeration_18',['Device Enumeration',['../group__devenum.html',1,'']]],
  ['device_5fdelivered_19',['device_delivered',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ab62d16cc71398e9362feb3320b4705cb',1,'IC4_STREAM_STATS::device_delivered()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ab62d16cc71398e9362feb3320b4705cb',1,'IC4_STREAM_STATS_V2::device_delivered()']]],
  ['device_5fframe_5fnumber_20',['device_frame_number',['../struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a1e111673ebc53c5f4118562d87487ced',1,'IC4_FRAME_METADATA']]],
  ['device_5ftimestamp_5fns_21',['device_timestamp_ns',['../struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a3ffd50c722ad4a9a82f9d3faa820abb4',1,'IC4_FRAME_METADATA']]],
  ['device_5ftransform_5funderrun_22',['device_transform_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#a5074cff63bae255d547fba0277698eaf',1,'IC4_STREAM_STATS_V2']]],
  ['device_5ftransmission_5ferror_23',['device_transmission_error',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ad6c254ea67852baa501a3758861aa871',1,'IC4_STREAM_STATS::device_transmission_error()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ad6c254ea67852baa501a3758861aa871',1,'IC4_STREAM_STATS_V2::device_transmission_error()']]],
  ['device_5funderrun_24',['device_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ae8447e6f4ed71ef03da194f914b48190',1,'IC4_STREAM_STATS::device_underrun()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ae8447e6f4ed71ef03da194f914b48190',1,'IC4_STREAM_STATS_V2::device_underrun()']]],
  ['display_25',['Display',['../group__display.html',1,'']]],
  ['device_20enumeration_26',['Device Enumeration',['../guide_device_enumeration.html',1,'programmers_guide']]],
  ['distributing_20your_20applications_27',['Distributing Your Applications',['../technical_article_distributing_your_applications.html',1,'technical_articles']]]
];
