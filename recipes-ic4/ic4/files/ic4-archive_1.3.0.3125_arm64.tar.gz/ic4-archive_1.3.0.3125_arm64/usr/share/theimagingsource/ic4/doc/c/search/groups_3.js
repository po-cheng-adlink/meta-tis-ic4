var searchData=
[
  ['enumeration_20properties_1243',['Enumeration Properties',['../group__enumprop.html',1,'']]],
  ['error_20handling_1244',['Error Handling',['../group__error.html',1,'']]]
];
