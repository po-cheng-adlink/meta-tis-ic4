var group__cmdprop =
[
    [ "ic4_prop_command_execute", "group__cmdprop.html#ga3207610d01d8b603ee718d28bf0d5490", null ],
    [ "ic4_prop_command_is_done", "group__cmdprop.html#ga20b0cd5d31445e178e0996b59a471d46", null ]
];