var group__stringprop =
[
    [ "ic4_prop_string_get_max_len", "group__stringprop.html#gafd12e61c3c9442cb3c09494d82ad41c9", null ],
    [ "ic4_prop_string_get_value", "group__stringprop.html#ga760d15988d9b6bfbfb1067b4bc648735", null ],
    [ "ic4_prop_string_set_value", "group__stringprop.html#ga00c55eb8227c72e7ee985cfca6da0ef9", null ]
];