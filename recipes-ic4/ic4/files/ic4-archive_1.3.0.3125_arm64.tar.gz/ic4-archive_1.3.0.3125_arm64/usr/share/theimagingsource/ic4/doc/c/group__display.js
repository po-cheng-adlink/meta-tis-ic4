var group__display =
[
    [ "IC4_DISPLAY_STATS", "struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html", [
      [ "num_frames_displayed", "struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#ac9cd5dd300c6438c82021c0e2dc90be5", null ],
      [ "num_frames_dropped", "struct_i_c4___d_i_s_p_l_a_y___s_t_a_t_s.html#afcea9bf1389f82988d205a8d2d5f68a4", null ]
    ] ],
    [ "IC4_DISPLAY", "struct_i_c4___d_i_s_p_l_a_y.html", null ],
    [ "IC4_WINDOW_HANDLE_NULL", "group__display.html#gaf527b9c461e9d2f9f65b698b780db7db", null ],
    [ "ic4_display_window_closed_deleter", "group__display.html#ga750b9d917c77294a8d6ea97d5233a542", null ],
    [ "ic4_display_window_closed_handler", "group__display.html#ga953b9c8ccfabd73e0b9eeab60bd43154", null ],
    [ "IC4_WINDOW_HANDLE", "group__display.html#gabbe3fa6622826e0bcfe72727ad53c489", null ],
    [ "IC4_DISPLAY_RENDER_POSITION", "group__display.html#ga292f151c9e308b24bd785c02f7a3a125", [
      [ "IC4_DISPLAY_RENDER_POSITION_TOPLEFT", "group__display.html#gga292f151c9e308b24bd785c02f7a3a125a673307c3180718e108849d7cae14e352", null ],
      [ "IC4_DISPLAY_RENDER_POSITION_CENTER", "group__display.html#gga292f151c9e308b24bd785c02f7a3a125ab6c74c0901c1d1b4ef75f6259a6f35aa", null ],
      [ "IC4_DISPLAY_RENDER_POSITION_STRETCH_TOPLEFT", "group__display.html#gga292f151c9e308b24bd785c02f7a3a125ab2344bd3d407d737225e0e189a26868f", null ],
      [ "IC4_DISPLAY_RENDER_POSITION_STRETCH_CENTER", "group__display.html#gga292f151c9e308b24bd785c02f7a3a125a60f2569f7c3fcb2616d5ca665923d786", null ],
      [ "IC4_DISPLAY_RENDER_POSITION_CUSTOM", "group__display.html#gga292f151c9e308b24bd785c02f7a3a125ab6148415996dd555ffe221261e4431fa", null ]
    ] ],
    [ "IC4_DISPLAY_TYPE", "group__display.html#ga56f272899566014f48dba5fa0f5ff064", [
      [ "IC4_DISPLAY_DEFAULT", "group__display.html#gga56f272899566014f48dba5fa0f5ff064a5b4a9b66a8ab51e4392f2b461b08f57f", null ],
      [ "IC4_DISPLAY_WIN32_OPENGL", "group__display.html#gga56f272899566014f48dba5fa0f5ff064a3e56c7298cc559e0f894c320ffecb065", null ]
    ] ],
    [ "ic4_display_create", "group__display.html#gaacaa5daf6bb48f41b95c67baca4f2938", null ],
    [ "ic4_display_create_external_opengl", "group__display.html#ga523852a34d25f7893705d6ed7115c2f0", null ],
    [ "ic4_display_display_buffer", "group__display.html#ga8e8458e8ac1330a4862f058c99ae4d27", null ],
    [ "ic4_display_event_add_window_closed", "group__display.html#ga15cabcd43c04322a10a318a4edda78cc", null ],
    [ "ic4_display_event_remove_window_closed", "group__display.html#ga99554cb49e3cdc4b62175f5956e07459", null ],
    [ "ic4_display_external_opengl_initialize", "group__display.html#gaaa0201120bf9af96d5568494da2ac640", null ],
    [ "ic4_display_external_opengl_notify_window_closed", "group__display.html#ga215a164db54ff97d0e4a014e83aa3b89", null ],
    [ "ic4_display_external_opengl_render", "group__display.html#ga4c3f98277fbc12d1681f3c8d73200c46", null ],
    [ "ic4_display_get_stats", "group__display.html#gad5d41e5fc5e683c57350e03892755707", null ],
    [ "ic4_display_ref", "group__display.html#gad4f88460852ecf4ccb532761965e70c9", null ],
    [ "ic4_display_set_render_position", "group__display.html#ga5c3f687000bbe75a7d9f937f6d84b759", null ],
    [ "ic4_display_unref", "group__display.html#gae3c7602a970718113945070d76544cdb", null ]
];