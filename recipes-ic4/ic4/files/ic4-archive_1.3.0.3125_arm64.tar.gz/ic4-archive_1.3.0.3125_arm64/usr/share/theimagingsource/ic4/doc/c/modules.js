var modules =
[
    [ "Image Buffers", "group__imgbuf.html", "group__imgbuf" ],
    [ "Device Enumeration", "group__devenum.html", "group__devenum" ],
    [ "Display", "group__display.html", "group__display" ],
    [ "Error Handling", "group__error.html", "group__error" ],
    [ "Grabber", "group__grabber.html", "group__grabber" ],
    [ "Core Library Functions", "group__library.html", "group__library" ],
    [ "Properties", "group__properties.html", "group__properties" ],
    [ "Saving Images", "group__saveimages.html", "group__saveimages" ],
    [ "Sinks", "group__sink.html", "group__sink" ],
    [ "Video Writer", "group__videowriter.html", "group__videowriter" ],
    [ "Graphical User Interface Functions", "group__ic4gui.html", "group__ic4gui" ]
];