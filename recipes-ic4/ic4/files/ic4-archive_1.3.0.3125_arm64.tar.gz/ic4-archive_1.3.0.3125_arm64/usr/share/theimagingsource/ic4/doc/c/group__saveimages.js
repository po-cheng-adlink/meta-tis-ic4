var group__saveimages =
[
    [ "IC4_IMAGEBUFFER_SAVE_OPTIONS_BMP", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___b_m_p.html", [
      [ "store_bayer_raw_data_as_monochrome", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___b_m_p.html#a8e11af713954f39b9f386d9d5cbd41d5", null ]
    ] ],
    [ "IC4_IMAGEBUFFER_SAVE_OPTIONS_PNG", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___p_n_g.html", [
      [ "compression_level", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___p_n_g.html#ae1b570b709d899314a89e12d1dca5ae2", null ],
      [ "store_bayer_raw_data_as_monochrome", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___p_n_g.html#a8e11af713954f39b9f386d9d5cbd41d5", null ]
    ] ],
    [ "IC4_IMAGEBUFFER_SAVE_OPTIONS_JPEG", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___j_p_e_g.html", [
      [ "quality_pct", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___j_p_e_g.html#af573731d28103c8932b331c88b2c1997", null ]
    ] ],
    [ "IC4_IMAGEBUFFER_SAVE_OPTIONS_TIFF", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___t_i_f_f.html", [
      [ "store_bayer_raw_data_as_monochrome", "struct_i_c4___i_m_a_g_e_b_u_f_f_e_r___s_a_v_e___o_p_t_i_o_n_s___t_i_f_f.html#a8e11af713954f39b9f386d9d5cbd41d5", null ]
    ] ],
    [ "IC4_PNG_COMPRESSION_LEVEL", "group__saveimages.html#gaea7d38a8cfd4ada0918b0b5c56a13edb", [
      [ "IC4_PNG_COMPRESSION_AUTO", "group__saveimages.html#ggaea7d38a8cfd4ada0918b0b5c56a13edbad4acce77cd905a7647f150ccac0551ac", null ],
      [ "IC4_PNG_COMPRESSION_LOW", "group__saveimages.html#ggaea7d38a8cfd4ada0918b0b5c56a13edbaffd17514dfbbd04960615bec4268c8d5", null ],
      [ "IC4_PNG_COMPRESSION_MEDIUM", "group__saveimages.html#ggaea7d38a8cfd4ada0918b0b5c56a13edba43533bd55ef0b61a7b6e9847bba42ac5", null ],
      [ "IC4_PNG_COMPRESSION_HIGH", "group__saveimages.html#ggaea7d38a8cfd4ada0918b0b5c56a13edba04e0ee9d06100cddbaed4e5c6303912d", null ],
      [ "IC4_PNG_COMPRESSION_HIGHEST", "group__saveimages.html#ggaea7d38a8cfd4ada0918b0b5c56a13edbada43b8f37286d8600a12cc6ea84ea28f", null ]
    ] ],
    [ "ic4_imagebuffer_save_as_bmp", "group__saveimages.html#ga75cb7c1dbf2e479775a13feb8f9365ff", null ],
    [ "ic4_imagebuffer_save_as_jpeg", "group__saveimages.html#ga18e1a78a234f46e387208393d3b9975c", null ],
    [ "ic4_imagebuffer_save_as_png", "group__saveimages.html#gad35ec8d4fea9fe5638d475b86eac2ae1", null ],
    [ "ic4_imagebuffer_save_as_tiff", "group__saveimages.html#ga057cf56fc55d1e149de92cd92852cc0c", null ]
];