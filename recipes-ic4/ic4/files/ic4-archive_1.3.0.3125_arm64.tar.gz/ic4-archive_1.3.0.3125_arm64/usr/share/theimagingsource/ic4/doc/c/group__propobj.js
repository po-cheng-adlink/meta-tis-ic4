var group__propobj =
[
    [ "Category Properties", "group__catprop.html", "group__catprop" ],
    [ "Command Properties", "group__cmdprop.html", "group__cmdprop" ],
    [ "Integer Properties", "group__intprop.html", "group__intprop" ],
    [ "Float Properties", "group__floatprop.html", "group__floatprop" ],
    [ "Boolean Properties", "group__boolprop.html", "group__boolprop" ],
    [ "String Properties", "group__stringprop.html", "group__stringprop" ],
    [ "Enumeration Properties", "group__enumprop.html", "group__enumprop" ],
    [ "Register Properties", "group__regprop.html", "group__regprop" ],
    [ "IC4_PROPERTY", "struct_i_c4___p_r_o_p_e_r_t_y.html", null ],
    [ "ic4_prop_notification", "group__propobj.html#gacd5aff1e4302ced3bde02d91a7e3d760", null ],
    [ "ic4_prop_notification_deleter", "group__propobj.html#ga66e606697eef4b236afabedfc028b8b9", null ],
    [ "IC4_PROPERTY_INCREMENT_MODE", "group__propobj.html#gac077255568928a60b6fcb78b032ab109", [
      [ "IC4_PROPINCMODE_INCREMENT", "group__propobj.html#ggac077255568928a60b6fcb78b032ab109a69ee70af1cca77f137420fe9e97f92cd", null ],
      [ "IC4_PROPINCMODE_VALUESET", "group__propobj.html#ggac077255568928a60b6fcb78b032ab109a4ed93e7b670a02acd159071bd7dfda51", null ],
      [ "IC4_PROPINCMODE_NONE", "group__propobj.html#ggac077255568928a60b6fcb78b032ab109adf36d2bee57107b659ce81b86a1b69e0", null ]
    ] ],
    [ "IC4_PROPERTY_TYPE", "group__propobj.html#ga422e4777b2d2a1963a6d3baab7050f30", [
      [ "IC4_PROPTYPE_INVALID", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a8d809034958998ed6b17d5be960444f8", null ],
      [ "IC4_PROPTYPE_INTEGER", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a08700bc2e1d69a6b2f4be0eeb3d3c2c3", null ],
      [ "IC4_PROPTYPE_FLOAT", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30aa75724cdd67e9fa95d887583b6841566", null ],
      [ "IC4_PROPTYPE_ENUMERATION", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30afec91a04ce0eee0956f2f68ee6bec711", null ],
      [ "IC4_PROPTYPE_BOOLEAN", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a05d8f4623c1a27406f3ec727b8820af3", null ],
      [ "IC4_PROPTYPE_STRING", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30aa37e3386038f72fb5e08619d18635edd", null ],
      [ "IC4_PROPTYPE_COMMAND", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a3d9997246145c0cb07dba0bcbbaecbe4", null ],
      [ "IC4_PROPTYPE_CATEGORY", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a1beca8cdf5a73f7d3dfd23b199a033b6", null ],
      [ "IC4_PROPTYPE_REGISTER", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a48405c3b02710f2d7ec45a543503b6dc", null ],
      [ "IC4_PROPTYPE_PORT", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a3ec1314b8e50035ce9d8d536f98911bd", null ],
      [ "IC4_PROPTYPE_ENUMENTRY", "group__propobj.html#gga422e4777b2d2a1963a6d3baab7050f30a8233c71fdf80f54763522adf9b218949", null ]
    ] ],
    [ "IC4_PROPERTY_VISIBILITY", "group__propobj.html#ga164560530fbd6439992abaee0124bb6f", [
      [ "IC4_PROPVIS_BEGINNER", "group__propobj.html#gga164560530fbd6439992abaee0124bb6fa9c01b6b13a58db15f0574a696661bbeb", null ],
      [ "IC4_PROPVIS_EXPERT", "group__propobj.html#gga164560530fbd6439992abaee0124bb6fa000618bc0bc85f18af0edbb322e9b731", null ],
      [ "IC4_PROPVIS_GURU", "group__propobj.html#gga164560530fbd6439992abaee0124bb6fade847dc571ca9fba865a254de81cb264", null ],
      [ "IC4_PROPVIS_INVISIBLE", "group__propobj.html#gga164560530fbd6439992abaee0124bb6fa28fdc7e58fa4b2624f0e493cbc30d0d1", null ]
    ] ],
    [ "ic4_prop_event_add_notification", "group__propobj.html#gae1b126b1caa2a881024c558111bd713a", null ],
    [ "ic4_prop_event_remove_notification", "group__propobj.html#ga40c104b89d302db58dcf9c1b07caafdd", null ],
    [ "ic4_prop_get_description", "group__propobj.html#gab093fed172f93c2b091fad8ddcf6f50d", null ],
    [ "ic4_prop_get_display_name", "group__propobj.html#ga0a759849682b1bc1491e3d01deca1abc", null ],
    [ "ic4_prop_get_name", "group__propobj.html#ga4de87ceb835307c966aeab0948b04e2b", null ],
    [ "ic4_prop_get_selected_props", "group__propobj.html#gaf5524f5bd4f1a3bdffc0ec1d11908e0a", null ],
    [ "ic4_prop_get_tooltip", "group__propobj.html#gae16b9a801a72c7893ae30a1e03404d10", null ],
    [ "ic4_prop_get_type", "group__propobj.html#gae697adcf73fdfc4859f80732e89ea3c4", null ],
    [ "ic4_prop_get_visibility", "group__propobj.html#ga1bec62b590f9f4207552854b58e02c6e", null ],
    [ "ic4_prop_is_available", "group__propobj.html#gab128ac334dfa9e939027d55fb41237c8", null ],
    [ "ic4_prop_is_likely_locked_by_stream", "group__propobj.html#gaa5123c2612d5311d05b0994e0f557a8e", null ],
    [ "ic4_prop_is_locked", "group__propobj.html#gab797ec8ffad1d83d942b816f08b3155b", null ],
    [ "ic4_prop_is_readonly", "group__propobj.html#ga1aa798a009c96903126100949b8c629d", null ],
    [ "ic4_prop_is_selector", "group__propobj.html#ga91f4b29e4e59ad32187ff6bd8c5d672d", null ],
    [ "ic4_prop_ref", "group__propobj.html#ga716d23fa640f187c142c362236488fea", null ],
    [ "ic4_prop_unref", "group__propobj.html#ga461ac8b05cb006380a5312398736675e", null ]
];