var searchData=
[
  ['output_5fqueue_5flength_1025',['output_queue_length',['../struct_i_c4___q_u_e_u_e_s_i_n_k___q_u_e_u_e___s_i_z_e_s.html#abeddbceb1598ad07d061a33d1e00927d',1,'IC4_QUEUESINK_QUEUE_SIZES']]]
];
