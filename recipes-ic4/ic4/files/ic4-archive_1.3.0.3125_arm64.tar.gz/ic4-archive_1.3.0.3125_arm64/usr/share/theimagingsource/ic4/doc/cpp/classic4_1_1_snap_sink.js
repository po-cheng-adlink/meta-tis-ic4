var classic4_1_1_snap_sink =
[
    [ "Config", "structic4_1_1_snap_sink_1_1_config.html", "structic4_1_1_snap_sink_1_1_config" ],
    [ "CustomAllocationStrategy", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy.html", "structic4_1_1_snap_sink_1_1_custom_allocation_strategy" ],
    [ "AllocationStrategy", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5f", [
      [ "Default", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5fa7a1920d61156abc05a60135aefe8bc67", null ],
      [ "Custom", "classic4_1_1_snap_sink.html#ab96871c28164299debdb357e4f932a5fa90589c47f06eb971d548591f23c285af", null ]
    ] ],
    [ "outputImageType", "classic4_1_1_snap_sink.html#a6e27acb23a70ed2c03b6bc3d6ad056cd", null ],
    [ "sinkType", "classic4_1_1_snap_sink.html#a97dac7bcfe21d2073c88b7432424bff1", null ],
    [ "snapSequence", "classic4_1_1_snap_sink.html#aa948e60336452794566735511177c69f", null ],
    [ "snapSequence", "classic4_1_1_snap_sink.html#a30e1ac229d7c8b0ab951ca47bd26d383", null ],
    [ "snapSingle", "classic4_1_1_snap_sink.html#adad15d0226bac54de324224f613fdf92", null ],
    [ "snapSingle", "classic4_1_1_snap_sink.html#a3b093e1d79bd590834e930c183215c5c", null ]
];