var classic4_1_1_sink =
[
    [ "SinkMode", "classic4_1_1_sink.html#ada1f25ce8b6a2e35ca2a001e25ec01e9", [
      [ "Run", "classic4_1_1_sink.html#ada1f25ce8b6a2e35ca2a001e25ec01e9ac5301693c4e792bcd5a479ef38fb8f8d", null ],
      [ "Pause", "classic4_1_1_sink.html#ada1f25ce8b6a2e35ca2a001e25ec01e9a105b296a83f9c105355403f3332af50f", null ]
    ] ],
    [ "~Sink", "classic4_1_1_sink.html#a6653b77966b4ca7d13c91957768bef0d", null ],
    [ "isAttached", "classic4_1_1_sink.html#a1a4306e075f1351914d92d2a4bf7310a", null ],
    [ "setSinkMode", "classic4_1_1_sink.html#a341f621656a6819a5806193c398f5992", null ],
    [ "sinkMode", "classic4_1_1_sink.html#a6698fbf94da74badfeb2d698f6a010f3", null ],
    [ "sinkType", "classic4_1_1_sink.html#a472120ee1e3c4ae6ab5bd132eb17b6f6", null ]
];