var programmers_guide =
[
    [ "Getting Started", "guide_getting_started.html", [
      [ "Setup", "guide_getting_started.html#Setup", [
        [ "Windows", "guide_getting_started.html#Windows", null ],
        [ "Linux", "guide_getting_started.html#Linux", [
          [ "ic4.deb", "guide_getting_started.html#gettingstarted_linux_package_content_core", null ],
          [ "ic4-dev.deb", "guide_getting_started.html#gettingstarted_linux_package_content_dev", null ],
          [ "ic4-doc.deb", "guide_getting_started.html#gettingstarted_linux_package_content_doc", null ],
          [ "ic4-plugin-encoder.deb", "guide_getting_started.html#gettingstarted_linux_package_content_encoder", null ],
          [ "ic4-plugin-display.deb", "guide_getting_started.html#gettingstarted_linux_package_content_display", null ],
          [ "ic4-utils.deb", "guide_getting_started.html#gettingstarted_linux_package_content_utils", null ]
        ] ]
      ] ],
      [ "Setting Up the Project", "guide_getting_started.html#gs_setup", [
        [ "Using CMake", "guide_getting_started.html#gs_cmake", null ]
      ] ],
      [ "Hello IC4!", "guide_getting_started.html#gs_hello", null ]
    ] ],
    [ "Device Enumeration", "guide_device_enumeration.html", [
      [ "Simple Device Enumeration", "guide_device_enumeration.html#article_device_enumeration_simple", null ],
      [ "Query Interface/Device Topology", "guide_device_enumeration.html#article_device_enumeration_topology", null ],
      [ "Receiving Device Arrival and Removal Notifications", "guide_device_enumeration.html#article_device_enumeration_notifications", null ]
    ] ],
    [ "Configuring a Video Capture Device", "guide_configuring_device.html", [
      [ "Open a Device", "guide_configuring_device.html#gcd_open_device", null ],
      [ "Configure the Resolution", "guide_configuring_device.html#gcd_configure_resolution", null ],
      [ "Define ROI Origin", "guide_configuring_device.html#gcd_roi_origin", null ],
      [ "Set an Exposure Time", "guide_configuring_device.html#gcd_set_exposure", null ]
    ] ],
    [ "Grabbing an Image", "guide_grabbing_an_image.html", [
      [ "Opening and Configuring the Video Capture Device", "guide_grabbing_an_image.html#gi_open", null ],
      [ "Setting up the Sink and Data Stream", "guide_grabbing_an_image.html#gi_sink_ds", null ],
      [ "Grabbing an Image", "guide_grabbing_an_image.html#gi_grab", null ],
      [ "Stopping the Data Stream", "guide_grabbing_an_image.html#gi_stop", null ]
    ] ],
    [ "Minimal Requirements", "minimal_requirements.html", [
      [ "Windows", "minimal_requirements.html#windows_requiremets", null ],
      [ "Linux", "minimal_requirements.html#linux_requiremets", null ]
    ] ]
];