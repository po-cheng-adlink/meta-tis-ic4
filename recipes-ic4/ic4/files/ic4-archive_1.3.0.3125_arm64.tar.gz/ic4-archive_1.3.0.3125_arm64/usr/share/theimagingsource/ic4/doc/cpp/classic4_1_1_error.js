var classic4_1_1_error =
[
    [ "Error", "classic4_1_1_error.html#a2605b9d054fe04afe5b3b7426bc31a1f", null ],
    [ "code", "classic4_1_1_error.html#a80fd7b61ea5ca48eb58d6157f146fbca", null ],
    [ "isError", "classic4_1_1_error.html#abf659bab1bf951a66f33470804a14de2", null ],
    [ "isSuccess", "classic4_1_1_error.html#a39239f5a63b1104c2c139bf7ddad24cb", null ],
    [ "message", "classic4_1_1_error.html#a9fc62bb96c3174d6d9945644308ecc8c", null ],
    [ "operator bool", "classic4_1_1_error.html#a420e60e9788bfa3b52aa3aab72ea3a5e", null ]
];