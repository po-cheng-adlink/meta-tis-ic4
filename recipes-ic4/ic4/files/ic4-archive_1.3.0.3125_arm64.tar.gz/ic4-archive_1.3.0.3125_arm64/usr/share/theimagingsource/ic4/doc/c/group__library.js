var group__library =
[
    [ "IC4_INIT_CONFIG", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html", [
      [ "api_log_level", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#ac2e2c614ceb71c230bfa6b0b89b8476c", null ],
      [ "internal_log_level", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#abe396c0692242978c0346ef65c5ca1c9", null ],
      [ "log_file", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#aeee7252e51523f7c2fd39151ae7eaf05", null ],
      [ "log_targets", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#abe17511a4b5c176ab3c9f2c67a4ab8f2", null ],
      [ "reserved0", "struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#af739c5839fbc080ce2b6f70f24961d4b", null ]
    ] ],
    [ "IC4_LOG_LEVEL", "group__library.html#ga36342b5d9892c772781583c04a19998e", [
      [ "IC4_LOG_OFF", "group__library.html#gga36342b5d9892c772781583c04a19998ea65a74f6d9ff5df41084dd9ca7971e09d", null ],
      [ "IC4_LOG_ERROR", "group__library.html#gga36342b5d9892c772781583c04a19998eaed03b5bb2c0ba0b1c9084de22324e957", null ],
      [ "IC4_LOG_WARN", "group__library.html#gga36342b5d9892c772781583c04a19998ea20eef0a2b3f7b7c7b903edf6edaf0e9f", null ],
      [ "IC4_LOG_INFO", "group__library.html#gga36342b5d9892c772781583c04a19998eaf069dc6f9f8fc80160201bc0e7941b14", null ],
      [ "IC4_LOG_DEBUG", "group__library.html#gga36342b5d9892c772781583c04a19998ea5c22bff2b99cfd1eaa03122aa75dde37", null ],
      [ "IC4_LOG_TRACE", "group__library.html#gga36342b5d9892c772781583c04a19998ea14da659a280050b8e2e2f8e8a412bc6b", null ]
    ] ],
    [ "IC4_LOG_TARGET_FLAGS", "group__library.html#ga0f1dbef68be82d5c787d38cc587aab7e", [
      [ "IC4_LOGTARGET_DISABLE", "group__library.html#gga0f1dbef68be82d5c787d38cc587aab7eadf94b1b23661acbc14875eb9677ee930", null ],
      [ "IC4_LOGTARGET_STDOUT", "group__library.html#gga0f1dbef68be82d5c787d38cc587aab7ea45ce8a7fc79d7fb71dfb2c72d5d6cac5", null ],
      [ "IC4_LOGTARGET_STDERR", "group__library.html#gga0f1dbef68be82d5c787d38cc587aab7ea0ec02a5c9a0eef5e8ad79b3ce29cda44", null ],
      [ "IC4_LOGTARGET_FILE", "group__library.html#gga0f1dbef68be82d5c787d38cc587aab7ea3bef86e9f5b6d4e1dc69659e59c16a8d", null ],
      [ "IC4_LOGTARGET_WINDEBUG", "group__library.html#gga0f1dbef68be82d5c787d38cc587aab7ea9e7b488fd33f9a843dfc8da612f88e56", null ]
    ] ],
    [ "IC4_VERSION_INFO_FLAGS", "group__library.html#gab85a3014e4abc6766d5aabb5073d416b", [
      [ "IC4_VERSION_INFO_DEFAULT", "group__library.html#ggab85a3014e4abc6766d5aabb5073d416ba4a79d9ae379bfb5cc79a20a63d30d0a3", null ],
      [ "IC4_VERSION_INFO_ALL", "group__library.html#ggab85a3014e4abc6766d5aabb5073d416bada163ac7b21e4a2b20f9df13a716ec65", null ],
      [ "IC4_VERSION_INFO_IC4", "group__library.html#ggab85a3014e4abc6766d5aabb5073d416baa72a3374d82ad0eaea6ce8419a481584", null ],
      [ "IC4_VERSION_INFO_DRIVER", "group__library.html#ggab85a3014e4abc6766d5aabb5073d416bacb0a2c4d48b8b57f463c3ee29846e580", null ],
      [ "IC4_VERSION_INFO_PLUGINS", "group__library.html#ggab85a3014e4abc6766d5aabb5073d416bab427e1db699f731cf012ef9a053ea01f", null ]
    ] ],
    [ "ic4_exit_library", "group__library.html#ga8af3f36aaa7cc7bcc80205ce1c27633f", null ],
    [ "ic4_get_version_info", "group__library.html#gafe147f23925a22b15d0c8ded73ff6301", null ],
    [ "ic4_init_library", "group__library.html#gaae799f286f237070f2bab7de1bf7d012", null ]
];