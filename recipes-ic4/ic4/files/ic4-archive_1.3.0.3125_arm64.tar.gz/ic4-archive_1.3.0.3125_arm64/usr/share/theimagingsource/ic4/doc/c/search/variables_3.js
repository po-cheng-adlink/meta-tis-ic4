var searchData=
[
  ['device_5fdelivered_1001',['device_delivered',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ab62d16cc71398e9362feb3320b4705cb',1,'IC4_STREAM_STATS::device_delivered()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ab62d16cc71398e9362feb3320b4705cb',1,'IC4_STREAM_STATS_V2::device_delivered()']]],
  ['device_5fframe_5fnumber_1002',['device_frame_number',['../struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a1e111673ebc53c5f4118562d87487ced',1,'IC4_FRAME_METADATA']]],
  ['device_5ftimestamp_5fns_1003',['device_timestamp_ns',['../struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a3ffd50c722ad4a9a82f9d3faa820abb4',1,'IC4_FRAME_METADATA']]],
  ['device_5ftransform_5funderrun_1004',['device_transform_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#a5074cff63bae255d547fba0277698eaf',1,'IC4_STREAM_STATS_V2']]],
  ['device_5ftransmission_5ferror_1005',['device_transmission_error',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ad6c254ea67852baa501a3758861aa871',1,'IC4_STREAM_STATS::device_transmission_error()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ad6c254ea67852baa501a3758861aa871',1,'IC4_STREAM_STATS_V2::device_transmission_error()']]],
  ['device_5funderrun_1006',['device_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ae8447e6f4ed71ef03da194f914b48190',1,'IC4_STREAM_STATS::device_underrun()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ae8447e6f4ed71ef03da194f914b48190',1,'IC4_STREAM_STATS_V2::device_underrun()']]]
];
