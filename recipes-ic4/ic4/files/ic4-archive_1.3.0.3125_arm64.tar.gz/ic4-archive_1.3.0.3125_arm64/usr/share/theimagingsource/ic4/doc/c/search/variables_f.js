var searchData=
[
  ['title_1039',['title',['../struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#a8214780964530800368b406c681fd1d9',1,'IC4_PROPERTY_DIALOG_OPTIONS']]],
  ['transform_5fdelivered_1040',['transform_delivered',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#a24a49808b1a533ddc8c81ef9d8af49d1',1,'IC4_STREAM_STATS::transform_delivered()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#a24a49808b1a533ddc8c81ef9d8af49d1',1,'IC4_STREAM_STATS_V2::transform_delivered()']]],
  ['transform_5funderrun_1041',['transform_underrun',['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s.html#ad47903278206a6937c8b9d4bde7613a4',1,'IC4_STREAM_STATS::transform_underrun()'],['../struct_i_c4___s_t_r_e_a_m___s_t_a_t_s___v2.html#ad47903278206a6937c8b9d4bde7613a4',1,'IC4_STREAM_STATS_V2::transform_underrun()']]]
];
