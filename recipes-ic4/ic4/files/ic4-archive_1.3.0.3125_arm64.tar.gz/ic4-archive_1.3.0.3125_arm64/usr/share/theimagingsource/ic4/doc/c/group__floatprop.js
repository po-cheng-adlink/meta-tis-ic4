var group__floatprop =
[
    [ "IC4_PROPERTY_DISPLAY_NOTATION", "group__floatprop.html#ga4d40e2b98178d8cabb13cae01037118c", [
      [ "IC4_PROPDISPNOTATION_AUTOMATIC", "group__floatprop.html#gga4d40e2b98178d8cabb13cae01037118ca04cae29d7bda23837e6b9a7647cb1cd7", null ],
      [ "IC4_PROPDISPNOTATION_FIXED", "group__floatprop.html#gga4d40e2b98178d8cabb13cae01037118cab601a98625d28f931047cf33f19127a0", null ],
      [ "IC4_PROPDISPNOTATION_SCIENTIFIC", "group__floatprop.html#gga4d40e2b98178d8cabb13cae01037118ca4ce08eb5d81c8ccd66194e1c31126c52", null ]
    ] ],
    [ "IC4_PROPERTY_FLOAT_REPRESENTATION", "group__floatprop.html#gaa21029f637b3e80355f7bf95e0878c52", [
      [ "IC4_PROPFLOATREP_LINEAR", "group__floatprop.html#ggaa21029f637b3e80355f7bf95e0878c52aa96f0e2e09837d91cb4808e356fd0499", null ],
      [ "IC4_PROPFLOATREP_LOGARITHMIC", "group__floatprop.html#ggaa21029f637b3e80355f7bf95e0878c52a08c0d02e3678d538ddf8f42583ab6834", null ],
      [ "IC4_PROPFLOATREP_PURENUMBER", "group__floatprop.html#ggaa21029f637b3e80355f7bf95e0878c52a6fa93e492e97b1ebe831a4ec209f9b73", null ]
    ] ],
    [ "ic4_prop_float_get_display_notation", "group__floatprop.html#gaceb33de7c21549e7a2250822a40bb9d1", null ],
    [ "ic4_prop_float_get_display_precision", "group__floatprop.html#gad802f16dd01593d3d8d192d7deadf942", null ],
    [ "ic4_prop_float_get_inc", "group__floatprop.html#ga6f81e504ac071546d98638436a714d10", null ],
    [ "ic4_prop_float_get_inc_mode", "group__floatprop.html#gaef0b54650e98aecac725d46ec8bd8c2d", null ],
    [ "ic4_prop_float_get_max", "group__floatprop.html#ga634379c72397cd94844c4bce6ea84bb6", null ],
    [ "ic4_prop_float_get_min", "group__floatprop.html#ga7fa2f64a5e696f69b426d88fda8eb344", null ],
    [ "ic4_prop_float_get_representation", "group__floatprop.html#ga765dfd338c4eca2634bd93f421d4a498", null ],
    [ "ic4_prop_float_get_unit", "group__floatprop.html#ga41532d81eb17e207a81d4caa01bd9954", null ],
    [ "ic4_prop_float_get_valid_value_set", "group__floatprop.html#ga36811caa597a4433a4921b32a0fc74bd", null ],
    [ "ic4_prop_float_get_value", "group__floatprop.html#gafeb414f1b17e3e50710018495aa644e8", null ],
    [ "ic4_prop_float_set_value", "group__floatprop.html#ga888f7829ec4283ca3141dc9fdbd92ef0", null ]
];