var struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a =
[
    [ "device_frame_number", "struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a1e111673ebc53c5f4118562d87487ced", null ],
    [ "device_timestamp_ns", "struct_i_c4___f_r_a_m_e___m_e_t_a_d_a_t_a.html#a3ffd50c722ad4a9a82f9d3faa820abb4", null ]
];