var group__videowriter =
[
    [ "IC4_VIDEO_WRITER", "struct_i_c4___v_i_d_e_o___w_r_i_t_e_r.html", null ],
    [ "IC4_VIDEO_WRITER_TYPE", "group__videowriter.html#gace5c3f5f27e19435ffda60f9afa8dfb5", [
      [ "IC4_VIDEO_WRITER_MP4_H264", "group__videowriter.html#ggace5c3f5f27e19435ffda60f9afa8dfb5a7bd4a4954d014962bbf7af7b6032241a", null ],
      [ "IC4_VIDEO_WRITER_MP4_H265", "group__videowriter.html#ggace5c3f5f27e19435ffda60f9afa8dfb5ae2660004cd1fe75bbcc6311818824992", null ]
    ] ],
    [ "ic4_videowriter_add_frame", "group__videowriter.html#ga3f0bbb8cd5f5bd179e301bb41f9c3390", null ],
    [ "ic4_videowriter_add_frame_copy", "group__videowriter.html#gab52b7d16dedb6280fd9aae2110e836fd", null ],
    [ "ic4_videowriter_begin_file", "group__videowriter.html#ga283d2f726197a4c8b0072e428d1501c0", null ],
    [ "ic4_videowriter_create", "group__videowriter.html#ga4371fffe196454f09c450784dc6332f9", null ],
    [ "ic4_videowriter_finish_file", "group__videowriter.html#ga5a5a1253887eb185c6fe4e592e672436", null ],
    [ "ic4_videowriter_get_property_map", "group__videowriter.html#gad2bc0cf000dce86f1ecfc8d0c962c597", null ],
    [ "ic4_videowriter_ref", "group__videowriter.html#ga1b5dd4256e53d9712baf95a6a7130073", null ],
    [ "ic4_videowriter_unref", "group__videowriter.html#ga57f3da18dd9fe9de8227b8411e47efc9", null ]
];