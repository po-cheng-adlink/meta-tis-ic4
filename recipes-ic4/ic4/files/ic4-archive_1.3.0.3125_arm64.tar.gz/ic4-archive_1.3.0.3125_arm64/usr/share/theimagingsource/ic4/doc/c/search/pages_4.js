var searchData=
[
  ['getting_20started_1268',['Getting Started',['../guide_getting_started.html',1,'programmers_guide']]],
  ['grabbing_20an_20image_1269',['Grabbing an Image',['../guide_grabbing_an_image.html',1,'programmers_guide']]],
  ['grabber_20states_1270',['Grabber States',['../technical_article_grabber_states.html',1,'technical_articles']]]
];
