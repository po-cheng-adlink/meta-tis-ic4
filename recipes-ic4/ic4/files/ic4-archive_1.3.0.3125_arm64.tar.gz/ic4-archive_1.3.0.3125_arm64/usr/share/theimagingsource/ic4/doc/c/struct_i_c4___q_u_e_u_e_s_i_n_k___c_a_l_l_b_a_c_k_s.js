var struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s =
[
    [ "frames_queued", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a767a7af3c0252bcfec7a26629d38cfeb", null ],
    [ "release", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8", null ],
    [ "sink_connected", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#abf6ba871c9b60106378498ad202ee885", null ],
    [ "sink_disconnected", "struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a6af4ff55b37bd5127050ee997107eb7c", null ]
];