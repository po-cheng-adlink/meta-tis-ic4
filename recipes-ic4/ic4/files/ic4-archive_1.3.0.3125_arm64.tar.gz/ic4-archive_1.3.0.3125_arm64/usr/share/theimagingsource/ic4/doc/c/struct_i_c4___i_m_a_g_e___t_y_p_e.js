var struct_i_c4___i_m_a_g_e___t_y_p_e =
[
    [ "height", "struct_i_c4___i_m_a_g_e___t_y_p_e.html#a6ad4f820ce4e75cda0686fcaad5168be", null ],
    [ "pixel_format", "struct_i_c4___i_m_a_g_e___t_y_p_e.html#a96abb64301e2663893851df3d166d50d", null ],
    [ "width", "struct_i_c4___i_m_a_g_e___t_y_p_e.html#a325272ddd9a962f05deb905101d25cbd", null ]
];