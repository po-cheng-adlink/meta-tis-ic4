var searchData=
[
  ['log_5ffile_1015',['log_file',['../struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#aeee7252e51523f7c2fd39151ae7eaf05',1,'IC4_INIT_CONFIG']]],
  ['log_5ftargets_1016',['log_targets',['../struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#abe17511a4b5c176ab3c9f2c67a4ab8f2',1,'IC4_INIT_CONFIG']]]
];
