var technical_articles =
[
    [ "Grabber States", "technical_article_grabber_states.html", [
      [ "Initial State", "technical_article_grabber_states.html#state_initial", null ],
      [ "Device Opened", "technical_article_grabber_states.html#state_device_opened", null ],
      [ "Streaming", "technical_article_grabber_states.html#state_streaming", null ],
      [ "Acquisition Active", "technical_article_grabber_states.html#state_acquisition_active", null ],
      [ "Device Invalid", "technical_article_grabber_states.html#state_device_invalid", null ]
    ] ],
    [ "Accessing Device Properties", "technical_article_properties.html", [
      [ "Property Map", "technical_article_properties.html#article_properties_propertymap", [
        [ "Property Identifiers", "technical_article_properties.html#article_properties_propertyids", null ]
      ] ],
      [ "Property Objects", "technical_article_properties.html#article_properties_propertyobjects", null ],
      [ "Specialized Property Types", "technical_article_properties.html#article_properties_propertytypes", null ]
    ] ],
    [ "Error Handling", "technical_article_error_handling.html", null ],
    [ "Logging", "technical_article_logging.html", [
      [ "Initialize Logging", "technical_article_logging.html#logging_initialize", null ]
    ] ],
    [ "Distributing Your Applications", "technical_article_distributing_your_applications.html", [
      [ "Windows", "technical_article_distributing_your_applications.html#distribution_windows", [
        [ "Using A Setup Toolkit", "technical_article_distributing_your_applications.html#distributing_setup_toolkit", null ]
      ] ],
      [ "Linux", "technical_article_distributing_your_applications.html#distributing_linux", [
        [ "Packages", "technical_article_distributing_your_applications.html#distributing_linux_package_content", [
          [ "ic4.deb", "technical_article_distributing_your_applications.html#distributing_linux_package_content_core", null ],
          [ "ic4-plugin-encoder.deb", "technical_article_distributing_your_applications.html#distributing_linux_package_content_encoder", null ],
          [ "ic4-plugin-display.deb", "technical_article_distributing_your_applications.html#distributing_linux_package_content_display", null ]
        ] ]
      ] ]
    ] ]
];