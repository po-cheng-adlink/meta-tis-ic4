var searchData=
[
  ['technical_20articles_1275',['Technical Articles',['../technical_articles.html',1,'']]],
  ['transitioning_20from_20ic_20imaging_20control_203_2e5_20tisgrabber_1276',['Transitioning from IC Imaging Control 3.5 tisgrabber',['../whatsnew_from35.html',1,'whatsnew']]]
];
