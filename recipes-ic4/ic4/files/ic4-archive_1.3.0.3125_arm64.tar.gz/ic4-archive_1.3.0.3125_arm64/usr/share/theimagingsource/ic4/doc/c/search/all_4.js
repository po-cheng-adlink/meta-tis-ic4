var searchData=
[
  ['enumeration_20properties_28',['Enumeration Properties',['../group__enumprop.html',1,'']]],
  ['error_20handling_29',['Error Handling',['../group__error.html',1,'']]],
  ['example_20programs_30',['Example Programs',['../example_programs.html',1,'']]],
  ['error_20handling_31',['Error Handling',['../technical_article_error_handling.html',1,'technical_articles']]]
];
