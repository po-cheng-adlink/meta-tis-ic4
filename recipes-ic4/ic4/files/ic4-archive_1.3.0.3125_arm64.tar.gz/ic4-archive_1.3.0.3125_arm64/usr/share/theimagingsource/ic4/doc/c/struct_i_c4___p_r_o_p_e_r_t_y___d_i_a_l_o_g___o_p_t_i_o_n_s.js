var struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s =
[
    [ "category", "struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#a125628117df0d6a7dd6caa43f2afa61c", null ],
    [ "flags", "struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#abed978b60a674eef89dad81daff471f7", null ],
    [ "initial_filter", "struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#aaec0678b917bef4b164cf4e32cb02eec", null ],
    [ "initial_visibility", "struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#a2d9302ddd2e2ed3944b6697b86dacf3f", null ],
    [ "title", "struct_i_c4___p_r_o_p_e_r_t_y___d_i_a_l_o_g___o_p_t_i_o_n_s.html#a8214780964530800368b406c681fd1d9", null ]
];