var searchData=
[
  ['register_20properties_727',['Register Properties',['../group__regprop.html',1,'']]],
  ['release_728',['release',['../struct_i_c4___a_l_l_o_c_a_t_o_r___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8',1,'IC4_ALLOCATOR_CALLBACKS::release()'],['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_a_l_l_b_a_c_k_s.html#a7ba8d694b15c4d9259357eca4cf263f8',1,'IC4_QUEUESINK_CALLBACKS::release()']]],
  ['reserved0_729',['reserved0',['../struct_i_c4___i_n_i_t___c_o_n_f_i_g.html#af739c5839fbc080ce2b6f70f24961d4b',1,'IC4_INIT_CONFIG']]]
];
