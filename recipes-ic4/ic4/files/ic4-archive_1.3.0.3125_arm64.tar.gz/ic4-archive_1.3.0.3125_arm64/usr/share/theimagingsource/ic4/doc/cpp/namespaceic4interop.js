var namespaceic4interop =
[
    [ "Qt", "namespaceic4interop_1_1_qt.html", "namespaceic4interop_1_1_qt" ],
    [ "HALCON", "classic4interop_1_1_h_a_l_c_o_n.html", null ],
    [ "OpenCV", "classic4interop_1_1_open_c_v.html", null ]
];