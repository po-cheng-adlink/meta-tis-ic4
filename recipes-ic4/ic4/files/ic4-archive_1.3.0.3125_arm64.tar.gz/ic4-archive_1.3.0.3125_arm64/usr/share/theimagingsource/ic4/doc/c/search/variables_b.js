var searchData=
[
  ['pitch_1026',['pitch',['../struct_i_c4___b_u_f_f_e_r_p_o_o_l___a_l_l_o_c_a_t_i_o_n___o_p_t_i_o_n_s.html#a8b9619114eefd65cd8c9804ad6154215',1,'IC4_BUFFERPOOL_ALLOCATION_OPTIONS']]],
  ['pixel_5fformat_1027',['pixel_format',['../struct_i_c4___i_m_a_g_e___t_y_p_e.html#a96abb64301e2663893851df3d166d50d',1,'IC4_IMAGE_TYPE']]],
  ['pixel_5fformats_1028',['pixel_formats',['../struct_i_c4___q_u_e_u_e_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284',1,'IC4_QUEUESINK_CONFIG::pixel_formats()'],['../struct_i_c4___s_n_a_p_s_i_n_k___c_o_n_f_i_g.html#ab9959cb6f4b320f268bfcbe2e600b284',1,'IC4_SNAPSINK_CONFIG::pixel_formats()']]]
];
